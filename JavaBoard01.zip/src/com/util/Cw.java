package com.util;

public class Cw {
		public static final String DOT = "📚";		
		public static final String DOT_1 = "♡";
		
		//line() Dot 30개
				public static void line() {
					for(int i=0; i<24; i++) {
						Cw.w(DOT);
					}	Cw.wn("");
				}
				
				//
				public static void dot(int d) {
					for(int i=0; i<d; i++) {
						Cw.w(DOT_1);
					}
				}
		
		//Cw.wn
		public static void wn(String s) {
			System.out.println(s);
		}
		//Cw.w
		public static void w(String s) {
			System.out.print(s);
		}

		
}
