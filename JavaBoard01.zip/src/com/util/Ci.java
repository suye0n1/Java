package com.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Ci {
	static Scanner sc = new Scanner(System.in);
	//버퍼를 이용한 입력
	static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	static public String r() {
		//String cmd = sc.next();
		//return cmd
		//한 줄로 작성: return sc.next();
		return sc.next();
	}
	
	public static String r(String comment) {
		Cw.w(comment+":");
		return sc.next();
	}
	public static String rl(String comment) {
		Cw.w(comment+":");
		//14장 예외 처리
		try {
			//Scanner: 공백처리x reader.readLine(): 공백 처리가 가능
			return reader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		
	}
}