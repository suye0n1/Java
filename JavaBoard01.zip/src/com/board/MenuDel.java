package com.board;

import com.board.data.Data;
import com.util.Ci;
import com.util.Cw;

public class MenuDel {
	static void run() {
		Cw.wn("글 삭제");
		String cmd = Ci.r("삭제할 글 번호");
		
		//향상된 for문
//		for(Post p:Data.posts) {
//			if(cmd.equals(p.instanceNo+"")) {
//			//	Data.posts.remove(p); //삭제처리를 이곳에서 하면 에러가 남
//			}
//			//intstanceNo가 숫자이므로 +""를 해주면 문자열로 바뀜
//		}	
		
		int tempSearchIndex = 0;
		for(int i=0; i<Data.posts.size(); i++) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				// Data.posts.remove(p); //삭제처리를 이곳에서도 하면 에러가 남
				tempSearchIndex  = i;
			}
		}
		
		//삭제 처리
		Data.posts.remove(tempSearchIndex); //따로 삭제 처리
		Cw.wn("글 개수:"+Data.posts.size());
		
		//for문	
//		for(int i=0; i<Data.posts.size(); i++) {
//			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
//				Data.posts.remove(i);
//		}
//			}
	}
}
