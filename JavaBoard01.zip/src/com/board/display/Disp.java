package com.board.display;

import com.board.Board;
import com.util.Cw;

public class Disp {

	//📚*30
	//♡Library Board♡
	//📚*30
	
	//간판 함수 선언

	public static void title() {
		Cw.line();
		Cw.dot(15);
		Cw.w(Board.TITLE);
		Cw.dot(15);
		Cw.wn("");
		Cw.line();
	}

	//Menu
	public static void Menu() {
		Cw.w("1.글 목록 2.글 읽기 3.글쓰기 4.글 삭제 5.글 수정 e.종료");
	}
}
