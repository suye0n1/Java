package com.board;

import com.board.data.Data;
import com.board.data.Post;
import com.util.Ci;
import com.util.Cw;

public class MenuRead {
	static void run() {
		Cw.wn("글 읽기");
		String cmd = Ci.r("읽을 글 번호");
		//향상된 for문
		for(Post p:Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.infoForRead();
			}
		}
	}
}
