package com.board;

import com.board.display.Disp;
import com.util.Ci;
import com.util.Cw;

public class Menu {
	public static void run() {
		Cw.wn("------------------------------------");
		Disp.Menu();
		Cw.wn("");
		Cw.wn("------------------------------------");
		
		loop:
		while(true) {
			String cmd = Ci.r("입력하세요");
			switch(cmd) {
			case "1":
				MenuList.run();
				break;
			case "2":
				MenuRead.run();
				break;
			case "3":
				MenuWrite.run();
				break;
			case "4":
				MenuDel.run();
				break;
			case "5":
				MenuUpdate.run();
				break;
			case "e":
				Cw.wn("프로그램 종료");
				break loop;
			default:
				Cw.wn("다시 입력하세요");
				break;
			}
		}
	}
}
