package com.board.data;

import java.util.ArrayList;

public class Data {
	//배열리스트 posts /Post 클래스에 있는 글들을 posts에 저장
	public static ArrayList<Post> posts;
	
//	public static ArrayList<Post> posts = new ArrayList<>(); //new ArrayList<>();(객체 생성) 이곳에 해도 가능
	
	//배열리스트 동작 함수 loadData
	public static void loadData() {
		posts = new ArrayList<>();
	}
}
