package com.board.data;

import java.time.LocalDate;

import com.util.Cw;

public class Post {
	public static int no = 0; //공용 글 번호 / static 함수는 1.객체 생성없이 접근 가능 2.하나만 존재(어떤 클래스에 no변수가 만들어지든 no변수의 값은 하나만 존재)
	public int instanceNo = 0; //글 번호 /Post객체를 만들 때 저장할 수 있는 글 번호를 선언해줘야함
	public String title; 	//글 제목
	public String  content; //글 내용
	public String writer; 	//작성자
	public int hit;      	//조회수
	public String date; 	//작성일
	
	//글 제목, 내용, 작성자, 조회수, 작성일
	public Post(String title, String content, String writer) {
		
		no = no + 1; //1씩 증가
		instanceNo = no; //글 번호를 instanceNo에 저장
		this.title = title;
		this.content = content;
		this.writer = writer;
		LocalDate now = LocalDate.now(); //현재 날짜 출력하는 함수 LocalDate
		date = now.toString(); //tostring 문자열 형태로 출력, date 필드에 저장
	}
	
	public void infoForList() {
		Cw.w("글 번호:"+ instanceNo);
		Cw.w(" 글 제목:"+ title);
		Cw.w(" 작성자:"+ writer);
		Cw.w(" 조회수:"+ hit);
		Cw.wn(" 작성일:"+ date);
	}
	
	
	public void infoForRead() {
		Cw.w("글 제목:"+ title);
		Cw.w(" 작성자:"+ writer);
		Cw.w(" 조회수:"+ hit);
		Cw.w(" 작성일:"+ date);
		Cw.wn(" 글 내용"+ content);
	}
}
