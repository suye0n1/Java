package com.board;

import com.board.data.Data;
import com.board.display.Disp;

public class Board {
	
	public static final String TITLE =  "Library Board";
	
	public void run() {
		Data.loadData(); //데이터 초기화
		Disp.title();
		Menu.run();
	}
}
