package com.board;

import com.board.data.Data;
import com.board.data.Post;
import com.util.Cw;

public class MenuList {
	static void run() {
		Cw.wn("리스트");	
	//향상된 for문
	for(Post p:Data.posts) {
		p.infoForList();
	}
	
	//for(int i=0 i<Data.posts.size(); i++){
	//	Data.posts.get(i).info();
	// }
	
	}
}
