package com.board;

import com.board.data.Data;
import com.board.data.Post;
import com.util.Ci;
import com.util.Cw;

public class MenuUpdate {
	
	static void run() {
//		Cw.wn("수정하기");
//		String cmd = Ci.r("수정할 번호를 입력하세요");
//		
//		for(Post p:Data.posts) {
//			
//		}
//		
		
		
		
		
		Cw.wn("글 수정");
		String cmd = Ci.r("수정할 글 번호");
		
		//제목, 내용, 작성자 수정
		for(Post p:Data.posts) {
			if(cmd.equals(p.instanceNo+"")){
				String content = Ci.rl("수정할 글 내용");
				p.content = content;
				Cw.wn("글 수정 완료");
			}
		}
		
	}
	
	
	
}
