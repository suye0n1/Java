package com.board;

import com.board.data.Data;
import com.board.data.Post;
import com.util.Ci;
import com.util.Cw;

public class MenuWrite {
	static void run() {
		Cw.wn("글 쓰기");
		//글 제목
		String title;
		while(true) {
			title=Ci.rl("글 제목");
			if(title.length()>0) {
				break;
			} else {
				Cw.wn("다시 입력하세요");
			}
		}
		//글 내용
			String content;
			while(true) {
				content=Ci.rl("글 내용");
				if(content.length()>0) {
					break;
				} else {
					Cw.wn("다시 입력하세요");
				}
			}
		//작성자
				String writer;
				while(true) {
					writer=Ci.rl("작성자");
					if(writer.length()>0) {
						break;
					} else {
						Cw.wn("다시 입력하세요");
					}
				}
	
				Post p = new Post(title, content, writer);
				Data.posts.add(p);
				Cw.wn("글 작성 완료");
				}
			}
