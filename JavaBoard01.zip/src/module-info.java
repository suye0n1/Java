/**
 * 
 */
/**
 * @author GDJ 59
 *
 */
module JavaBoard01 {
}