package com.board;



public class Main {
	//throws IOException
	public static void main(String[] args) {
		Board board = new Board();
		board.run();

	}
}
