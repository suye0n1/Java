package com.board;

import com.util.Ci;
import com.util.Db;

public class Delete {
	public static void run() {
		System.out.println("☆글 삭제☆");
		String delNo = Ci.rl("삭제할 글번호를 입력하세요");
		//dbExecuteUpdate
		Db.dbExecuteUpdate("delete from board where no="+delNo);
		
	}
}
