package com.board;

import java.sql.SQLException;

import com.util.Db;

public class Reply {
	
	public static void run() {
		System.out.println("☆댓글☆");
	//	String ori_num = Ci.r("글 번호를 입력하세요");
		String sql = "select * from board where b_ori_num is not null"; //where b_ori_num="+ori_num;
		
		
		try {
			//select * from board limit 0,3; (첫페이지, 세개)

		//	Cw.wn("전송한sql문:"+sql);
			Db.result = Db.st.executeQuery(sql);

		//	result = st.executeQuery("select * from board");
			while(Db.result.next()) {
				// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
			// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String b_ori_num = Db.result.getString("b_ori_num");
			String b_re_text = Db.result.getString("b_re_text");

			System.out.println("================================================");
			System.out.println("글 번호: "+b_ori_num);
			System.out.println("글 내용: "+b_re_text);
			System.out.println("================================================");
			System.out.println("");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		}
}