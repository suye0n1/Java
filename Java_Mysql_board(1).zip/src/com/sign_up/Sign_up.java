package com.sign_up;

import com.util.Ci;
import com.util.Cw;

public class Sign_up {
		//회원가입
		public static void run() {
				Cw.wn("◎회원가입◎");
				Cw.wn("c:14세 미만 회원가입 g:14세 이상 회원가입  x:이전 메뉴");
				String id ="";
				String pw ="";
				
				while(true) {
					id=Ci.r("아이디");
					if(id.length()>0) {
						break;
					}else {
						Cw.wn("장난x");
					}
				}
				while(true) {
					pw=Ci.r("암호");
					if(pw.length()>0) {
						break;
					}else {
						Cw.wn("장난x");
					}
				}
				
				
//				loop:
//				while(true) {
//					String cmd = "";
//					switch(cmd) {
//					case "c":
//						Cw.wn("");
//						if(id.length()>0) {
//							break;
//						} else {
//							Cw.wn("다시 입력하세요");
//						}
					//case "v":
						//Cw.wn("")
//				}
//			}
			
				
		}
}
