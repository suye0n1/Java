package rpc01;

import java.util.Scanner;

public class rpc_01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i = 0;
		String cmd = "";
		
		
//		1 = 가위 2 = 바위 3 = 보
//		cmd = sc.next();는 while문 안에 작성! 밖에 적어주면 switch문이 무한 반복

		
		String result = "";
		
		xx:
			
		while(true) {
			cmd = sc.next();
		i = (int)(Math.random() * 3+1);
			
		switch(cmd) {
		case "가위" : 
		switch(i) {
		case 1: 
			result = "비김";
			break;
		
		case 2: 
			result = "짐";
			break;
			
		case 3: 
			result = "이김";
			break;
		}
		break;
		
		case "바위" :
		switch(i) {
		case 1: 
			result = "이김";
			break;
		
		case 2: 
			result = "비김";
			break;
			
		case 3: 
			result = "짐";
			break;
		}
		break;
		
		case "보":
		switch(i) {
		case 1: 
			result = "짐";
			break;
		
		case 2: 
			result = "이김";
			break;
			
		case 3: 
			result = "비김";
			break;
		}
		break;
		
		case"x":
				break xx;
		}
		System.out.println(result);
		
		}
		
	}	
}


