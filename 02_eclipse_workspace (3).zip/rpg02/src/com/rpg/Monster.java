package com.rpg;

public class Monster {
	String name;
	int hp;
	int attack;
	
	void info() {
		System.out.println("이름:"+name+" 체력:"+hp+" 공격력:"+attack);
	}
}
