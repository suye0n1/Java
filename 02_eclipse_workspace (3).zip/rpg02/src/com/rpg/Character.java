package com.rpg;

public class Character {
	String name;
	int hp;
	int attack;
	
//	void는 return을 안하는 함수
	
	void info() {
		System.out.println("이름:"+name+" 체력:"+hp+" 공격력:"+attack);
	}
}
