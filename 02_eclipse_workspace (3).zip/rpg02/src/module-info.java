/**
 * 
 */
/**
 * @author GDJ 59
 *
 */
module rpg02 {
}