package com.Kiosk_2;

public class Product_1 {
	
	String name;
	int price;
	int price_2;

	Product_1(String name, int price) {
		this.name = name;
		this.price = price;
	}
	
	

	public void info() {
		System.out.println(name + " 가격" + price + "원");
	}
}
