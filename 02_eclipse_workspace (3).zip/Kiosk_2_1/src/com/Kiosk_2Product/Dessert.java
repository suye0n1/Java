package com.Kiosk_2Product;

public class Dessert extends Product_1 {
	
	public Dessert(String name, int price) {
		
		super(name, price);
	}

	public void info() {
		System.out.println(name + " 가격" + price + "원");
	}
}
