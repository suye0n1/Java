package com.Kiosk_2Product;

public class Product_1 {

	//접근 지정자 public > protected > default > private
	//public 동일 패키지의 모든 클래스 + 다른 패키지의 모든 클래스
	public String name;
	public int price;
	public String Opt;

	public Product_1(String name, int price) {
		this.name = name;
		this.price = price;
   }
	
	

	public void info() {
	System.out.println(name + " 가격" + price + "원");
}
	
}
