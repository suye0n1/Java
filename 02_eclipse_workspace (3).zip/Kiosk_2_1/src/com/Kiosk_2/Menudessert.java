package com.Kiosk_2;

import com.Kiosk_2Product.Dessert;
import com.Kiosk_2Product.Product_1;

public class Menudessert {
	
	public static void run_2() {
		System.out.println("원하시는 메뉴를 입력해주세요");
		System.out.println("====2번 메뉴:디저트 리스트====");
		
		
		//4-6 디저트 메뉴 출력
	//	for(int i=3; i<6; i++) {
	//		Cw.wn(Kioskobj.products.get(i).name+" "+Kioskobj.products.get(i).price+"원");
	//	}
		
		//instanceof 사용해서 디저트 메뉴 불러오기
		for(Product_1 p : Kioskobj.products) {
			if(p instanceof Dessert) {
				//만약에 Product_1에는 없고 Dessert만 있는 객체(opt)가 있다면 ((Dessert).p).opt)로 지정해주면 됨
				System.out.println(p.name+" "+p.price+"원");
			}
		}
		
		
		System.out.println("========================");
		
//		2번 메뉴
		loop_c: while (true) {
			System.out.println("[1.소금마카롱/2.브라우니마카롱/3.인절미마카롱/y:이전 메뉴]");
			Kioskobj.cmd = Kioskobj.sc.next();
			
			switch (Kioskobj.cmd) {
			case "1":
				System.out.println("소금마카롱");
				Kioskobj.x = new Dessert("소금마카롱", 2000);
				Kioskobj.basket.add(new Order(Kioskobj.products.get(3)));
				break;

			case "2":
				System.out.println("브라우니마카롱");
				Kioskobj.x = new Dessert("브라우니마카롱", 2500);
				Kioskobj.basket.add(new Order(Kioskobj.products.get(4)));
				break;

			case "3":
				System.out.println("인절미마카롱");
				Kioskobj.x = new Dessert("인절미마카롱", 2500);
				Kioskobj.basket.add(new Order(Kioskobj.products.get(5)));
				break;

			case "y":
				break loop_c;
			}
		
	}
}
}
