package com.Kiosk_2;

public class Product_1 {
	String name;
	int price;

	Product_1(String name, int price) {
//		Priduct_1을 생성하면 this.name은 흑임자라떼만 가리킴!
		this.name = name;
		this.price = price;
	}

	public void info() {
		System.out.println(name + " 가격" + price + "원");
	}
}
