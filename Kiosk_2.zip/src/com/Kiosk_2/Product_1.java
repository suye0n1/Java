package com.Kiosk_2;

public class Product_1 {
	String name;
	int price;
	int price_2;

	Product_1(String name, int price, int price_2) {
//		Priduct_1을 생성하면 this.name은 흑임자라떼만 가리킴!
		this.name = name;
		this.price = price;
		this.price_2 = price_2;
	}
	//Product_1()에 두개를 선언할 수도 있고 세개를 선언할 수도 있음 
	//Product_1은 똑같이 선언하고 ()안에만 다르게 선언해주면 됨
	Product_1(String name, int price) {
		this.name = name;
		this.price = price;
	}

	public void info() {
		System.out.println(name + " 가격" + price + "원");
	}
}
