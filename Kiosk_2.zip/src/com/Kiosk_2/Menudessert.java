package com.Kiosk_2;

public class Menudessert {
	
	public void run_2() {
		System.out.println("원하시는 메뉴를 입력해주세요");
		System.out.println("====디저트 리스트====");
		System.out.println("2번 메뉴");
		Kiosk_2.p4.info();
		Kiosk_2.p5.info();
		Kiosk_2.p6.info();
		
		
//		2번 메뉴
		loop_c: while (true) {
			System.out.println("[1.소금마카롱/2.브라우니마카롱/3.인절미마카롱/y:이전 메뉴]");
			Kiosk_2.cmd = Kiosk_2.sc.next();
			switch (Kiosk_2.cmd) {
			case "1":
				System.out.println("소금마카롱");
				Kiosk_2.x = new Product_1("소금마카롱", 2000);
				Kiosk_2.basket.add(Kiosk_2.x);
				break;

			case "2":
				System.out.println("브라우니마카롱");
				Kiosk_2.x = new Product_1("브라우니마카롱", 2500);
				Kiosk_2.basket.add(Kiosk_2.x);
				break;

			case "3":
				System.out.println("인절미마카롱");
				Kiosk_2.x = new Product_1("인절미마카롱", 2500);
				Kiosk_2.basket.add(Kiosk_2.x);
				break;

			case "y":
				break loop_c;
			}
		
	}
}
}
