package com.Kiosk_2;

import java.util.ArrayList;
import java.util.Scanner;

public class New_Main {

	public static void main(String[] args) {
		ArrayList<Product_1> basket = new ArrayList<Product_1>();
		Product_1 x;
//			위에 Product_1 x;를 선언하지 않고 
//			switch (cmd) case "1" 안에 Product_1 x = new Product_1 ("흑임자라떼", 6500); 쓰게 되면 
//			Product_1 x라는 박스를 계속 만들게 됨 그래서 맨 위에 Product_1 x를 선언을 해주면
//			case "1"에서는 박스를 계속 생성하지 않음 switch (cmd) case "1" 흑임자라떼를 또 선택하면
//			박스를 생성하지 않고 안에서 수정이 일어남

//		new Product_1를 생성하고  
		Product_1 p1 = new Product_1("흑임자라떼", 6000);
		Product_1 p2 = new Product_1("말차프라푸치노", 5500);
		Product_1 p3 = new Product_1("자몽에이드", 6500);

		Product_1 p4 = new Product_1("소금마카롱", 2000);
		Product_1 p5 = new Product_1("브라우니마카롱", 2500);
		Product_1 p6 = new Product_1("인절미마카롱", 2500);

		Scanner sc = new Scanner(System.in);
		String cmd;

		loop_a: while (true) {
			System.out.println("명령을 입력해주세요:[1.1번 메뉴/2.2번 메뉴/e:종료]");
			cmd = sc.next();

//			1번 메뉴
			switch (cmd) {
			case "1":
				System.out.println("=====음료 리스트====");
				System.out.println("1번 메뉴");
				p1.info();
				p2.info();
				p3.info();
				loop_b: while (true) {
					System.out.println("[1.흑임자라떼/2.말차프라푸치노/3.자몽에이드/x:이전 메뉴]");
					cmd = sc.next();
//					p1.info();/p2.info();/p3.info(); 이곳에 쓰고 case1을 누르면 흑임자라떼가 나오고 다음 줄에 info정보가 나오게 됨

					switch (cmd) {
					case "1":
						System.out.println("흑임자라떼");
//						흑임자라떼 6500d원을 x박스에 넣음
						x = new Product_1("흑임자라떼", 6000);
//						basket에 추가
						basket.add(x);
//					switch에 대한 break
						break;

					case "2":
						System.out.println("말차프라푸치노");
						x = new Product_1("말차프라푸치노", 5500);
						basket.add(x);
						break;

					case "3":
						System.out.println("자몽에이드");
						x = new Product_1("자몽에이드", 6500);
						basket.add(x);
						break;

					case "x":
						break loop_b;
					}
				}
				break;

			case "2":
				System.out.println("====디저트 리스트====");
				System.out.println("2번 메뉴");
				p4.info();
				p5.info();
				p6.info();
//				2번 메뉴
				loop_c: while (true) {
					System.out.println("[1.소금마카롱/2.브라우니마카롱/3.인절미마카롱/y:이전 메뉴]");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						System.out.println("소금마카롱");
						x = new Product_1("소금마카롱", 2000);
						basket.add(x);
						break;

					case "2":
						System.out.println("브라우니마카롱");
						x = new Product_1("브라우니마카롱", 2500);
						basket.add(x);
						break;

					case "3":
						System.out.println("인절미마카롱");
						x = new Product_1("인절미마카롱", 2500);
						basket.add(x);
						break;

					case "y":
						break loop_c;
					}
				}
				break;

			case "e":
				break loop_a;

			}
		}
		System.out.println("프로그램 종료");

//		basket에 있는 ArrayList는 0번지부터 시작인데 basket.size count는 왜 1개부터 세는가?
		int count = basket.size();
		System.out.println(count);

		int sum = 0;
		for (int i = 0; i < basket.size(); i = i + 1) {
			sum = sum + basket.get(i).price;
		}

	}
}
