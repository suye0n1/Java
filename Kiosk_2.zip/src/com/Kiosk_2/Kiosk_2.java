package com.Kiosk_2;

import java.util.ArrayList;
import java.util.Scanner;


public class Kiosk_2 {
	
		  	Menudrink Menudrink = new Menudrink();
		  	Menudessert Menudessert = new Menudessert();
		  	//basket배열리스트
		  	public static ArrayList<Product_1> basket = new ArrayList<Product_1>();
		  	public static Product_1 x;
//				위에 Product_1 x;를 선언하지 않고 
//				switch (cmd) case "1" 안에 Product_1 x = new Product_1 ("흑임자라떼", 6500); 쓰게 되면 
//				Product_1 x라는 박스를 계속 만들게 됨 그래서 맨 위에 Product_1 x를 선언을 해주면
//				case "1"에서는 박스를 계속 생성하지 않음 switch (cmd) case "1" 흑임자라떼를 또 선택하면
//				박스를 생성하지 않고 안에서 수정이 일어남

//			new Product_1는 새로운 객체를 생성하고  
			public static Product_1 p1 = new Product_1("흑임자라떼", 6000);
			public static Product_1 p2 = new Product_1("말차프라푸치노", 5500);
			public static Product_1 p3 = new Product_1("자몽에이드", 6500);

			public static Product_1 p4 = new Product_1("소금마카롱", 2000);
			public static Product_1 p5 = new Product_1("브라우니마카롱", 2500);
			public static Product_1 p6 = new Product_1("인절미마카롱", 2500);
//			public static을 써주면 어디서나 사용 가능(Menudrink에서 사용 가능)
			public static Scanner sc = new Scanner(System.in);
			public static String cmd;
			
			void run() {
				Disp.line();
				Disp.title();
				Disp.line();
			
			loop_a: while (true) {
				System.out.println("주문하기");
				System.out.println("명령을 입력해주세요:[1.1번 메뉴/2.2번 메뉴/e:종료]");
				cmd = sc.next();

//				1번 메뉴
				switch (cmd) {
				case "1":
					Menudrink.run_1();
					break;

				case "2":
					Menudessert.run_2();
					break;

				case "e":
					break loop_a;

				}
			}
			System.out.println("주문 종료");
			System.out.println("========주문 리스트=======");
		
			int count = basket.size();
			System.out.println("개수는 "+count);

			
			int sum = 0;
			
			//향상된 for문
			for(Product_1 b: basket) {
				sum = sum + b.price;
				System.out.println(b.name);
			}
			
			//for문
			for (int i = 0; i < basket.size(); i = i + 1) {
				sum = sum + basket.get(i).price;
				//바스켓배열리스트에서 선택된 음료, 디저트가 저장됨
				//불러오려면 basket.get(i).name 써주기 basket.get(i)가 오게 되면 x
				System.out.println(basket.get(i).name);
			}
				System.out.println("계산하실 금액은 "+sum+"입니다.");
				
		}
	}
	
