package com.Kiosk_2;

public class Menudrink {
	
	public void run_1() {
		System.out.println("원하시는 메뉴를 입력해주세요");
		System.out.println("=====음료 리스트====");
		System.out.println("1번 메뉴");
		
		Kiosk_2.p1.info();
		Kiosk_2.p2.info();
		Kiosk_2.p3.info();
		
		loop_b: while (true) {
			System.out.println("[1.흑임자라떼/2.말차프라푸치노/3.자몽에이드/x:이전 메뉴]");
			//입력 박스 생성
			Kiosk_2.cmd = Kiosk_2.sc.next();

			switch (Kiosk_2.cmd) {
			case "1":
				System.out.println("흑임자라떼");
				System.out.println("hot/ice 선택");
				String cmd = Kiosk_2.sc.next();
				// if(Kiosk_2.sc.next().equals(hot))으로 해주면 실행되기도 하고 안되기도 함
				//이유는 if문에서 입력을 기다리는 행위를 하고 else if문에서도 입력을 기다리는 행위를 다시 하기 때문에,,,,
				//그래서 바로 입력된 문장과 hot을 비교할 수 있도록(cmd.equals("hot")) if문 밖에서 먼저 선언을 해줌-String cmd = Kiosk_2.sc.next();
				if(cmd.equals("hot")) {
					System.out.println("흑임자라떼 hot 선택");
				}
			   else if(cmd.equals("ice")) {
					System.out.println("흑임자라떼 ice 선택");
				}
			   else {
					System.out.println("잘못 선택하셨습니다.");
				}

//				흑임자라떼 6000원을 x박스에 넣음
				Kiosk_2.x = new Product_1("흑임자라떼", 6000, 6500);
//				basket에 추가
				Kiosk_2.basket.add(Kiosk_2.x);
//			switch에 대한 break
				break;

			case "2":
				System.out.println("말차프라푸치노");
				Kiosk_2.x = new Product_1("말차프라푸치노", 5500);
				Kiosk_2.basket.add(Kiosk_2.x);
				break;

			case "3":
				System.out.println("자몽에이드");
				Kiosk_2.x = new Product_1("자몽에이드", 6500);
				Kiosk_2.basket.add(Kiosk_2.x);
				break;

			case "x":
				break loop_b;
			}
	}
}
}

