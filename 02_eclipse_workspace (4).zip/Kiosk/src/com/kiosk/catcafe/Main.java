package com.kiosk.catcafe;

import java.util.ArrayList;
//ctrl + shift + o (import 자동 생성)
import java.util.Scanner;

public class Main {
//	실행을 할 때 제일 먼저 main함수를 실행시킴(그러므로 임의로 이름을 바꾸면 안됨)
	public static void main(String[] args) {
//		배열 관리 리스트 ArrayList
		ArrayList<Product> basket = new ArrayList<Product>();
//		String으로 나오는 배열을 만들어라
		ArrayList<String> animals = new ArrayList<String>();

		animals.add("강아지"); // 0번째 강아지
		animals.add("고양이"); // 1번째 고양이 /넣을 때마다 크기가 늘어남
//		animals.set(1, "개"); //고양이 자리에 개가 들어감 
//		고양이 삭제

//		animals.remove(1);	//index 1번 제거/자리도 없애기 때문에 개수는 0번째 1개/뺄 때마다 크기가 줄어들음
//		animals.clear(); //전부 제거 

//		0번째 강아지가 나옴
		animals.get(0);
		String dog = animals.get(0);
		System.out.println(dog);

//		1번째 고양이가 나옴/remove(1)을 하려면 29,30,31줄 삭제
		animals.get(1);
		String cat = animals.get(1);
		System.out.println(cat);

//      개수
		int count = animals.size();
		System.out.println(count);

//		개수
		System.out.println(animals.size());

//      for문으로 강아지, 고양이 출력	
		for (int i = 0; i < animals.size(); i = i + 1) {
			System.out.println(animals.get(i));
		}

//		animals.contains("고양")으로 쓰면 고양이 없음
//		animals 배열 객체로 가서 고양이를 찾음/contains는 array 배열에 안에 있는 함수
//		animals 안에 고양이가 있으면 true로 변함!
		boolean hasCat = animals.contains("고양이");
		if (hasCat == true) {
			System.out.println("고양이 있음");

		} else {
			System.out.println("고양이 없음");
		}

//		메모리 구조 1.클래스 영역 2.스택 영역 3.힙 영역 
//		2.스택 영역에는 기본형(byte, int....) 존재 
//		int n = 100;
//		Cat kitty; //Cat kitty는 스택 영역에 저장 100번지라는 주소만 알려줌
//      3.힙 영역에는 객체가 저장(참조 자료형들(기본형 외)) 
//		new Cat();

//		Cat kitty = new Cat(); //100번지

//		간단하게 쓰기 가능(3)
		Product p1 = new Product("아메리카노", 2500);

//		product.java에 써줬기 때문에(1)
//		Product(String name, int price){
//			this.name = name;
//			this.price = price;

//		}
//		길게 써줄 필요없음(2)
//		Product p1 = new Product();
//		p1.name = "아메리카노";
//		p1.price = 2500;
		Product p2 = new Product("라떼", 3000);
//		Product p2 = new Product();
//		p2.name = "라떼";
//		p2.price = 3000;
		Product p3 = new Product("고구마케이크", 5500);
//		Product p3 = new Product();
//		p3.name = "고구마케이크";
//		p3.price = 5500;
		Product p4 = new Product("초코케이크", 5000);
//		Product p4 = new Product();
//		p4.name = "초코케이크";
//		p4.price = 5000;
		basket.add(p1);
		basket.add(p2);
		basket.add(p3);
		for (int i = 0; i < basket.size(); i = i + 1) {
			basket.get(i).info();

		}

//		원래는 자바폴더 안에 Util 안에  Scanner가 존재(java.Util.Scanner)
//		import를 써주면 java.util.Scanner라고 쓰지 않고 Scanner만 써줘도 됨
		Scanner sc = new Scanner(System.in);
//		cmd라는 박스를 만듦 밑에 cmd라는 함수만 사용할 수 있게
		String cmd;
//		중단하고자하는 해당 반복문 앞에 변수(loop_a:)를 써줌 변수이기 때문에 아무거나 가능
		loop_a:

		while (true) {
			System.out.println("메뉴:[1.음료/2.디저트/e:종료]");
//			cmd라는 함수만 사용 할 수 있게
			cmd = sc.next();
			switch (cmd) {
//			case구문을 쓸 경우 break문을 쓰고 시작
			case "1":
				System.out.println("==== 음료 리스트 ====");
				p1.info();
				p2.info();
				System.out.println("1번");
//				라벨을 지정
				loop_b: while (true) {
					System.out.println("메뉴:[1.아메리카노/2.라떼/x:이전메뉴]");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						System.out.println("아메리카노");
						break;

					case "2":
						System.out.println("라떼");
						break;

					case "x":
//					case에 있는 break;와는 다르기 때문에 loop_b라벨을 붙여줌 
						break loop_b;
					}
				}
				break;

			case "2":
				System.out.println("==== 디저트 리스트 ====");
				p3.info();
				p4.info();
				System.out.println("2번");
				loop_c: while (true) {
					System.out.println("메뉴:[1.고구마케이크/2.초코케이크/y:이전메뉴]");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						System.out.println("고구마케이크");
//						switch에 대한 break
						break;

					case "2":
						System.out.println("초코케이크");
						break;

					case "y":
						break loop_c;
					}
				}
				break;

			case "e":
//				switch에 대한 break로 작동하지 않고 while문 break 작동
				break loop_a;
			}
		}
		System.out.println("프로그램 종료");
	}

}
