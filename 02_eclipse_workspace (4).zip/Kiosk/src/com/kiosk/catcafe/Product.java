package com.kiosk.catcafe;

public class Product {
//	변수들
	String name;
	int price;
	
//	오버로딩: 매개변수(String name, int price)를 다르게 주는 경우(단, 매개변수를 다르게 줘야함) 똑같은 함수(Product)를 써도 에러가 나지 않음
//	생성자 함수 만들기 -매개변수 2개
	Product(String name, int price){
		this.name = name;
		this.price = price;
		
	}
	
//	오버로딩 가능
//	Product(String name){
//		this.name = name;
//		this.price = price;
//		
//	}
//	
//	Product(int price){
//		this.name = name;
//		this.price = price;
//		
//	}
	
//	Main.java에 가격 먼저 쓰고(ex)new Product(5000, 초코케이크))이름을 쓸 경우 이 함수로 와서 제대로 출력해줌
//	Product(int price, String name){
//		this.name = name;
//		this.price = price;
//		
//	}
	
	
	public void info() {
		System.out.println(name+" 가격:"+price+"원");
	}
	
//	Product copy() {
//		Product p = new Product(name, price);
//		return p;
//	}
}
