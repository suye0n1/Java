package com.Kiosk_q;

public class Kiosk {
	
	
	
}
