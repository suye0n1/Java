package com.Kiosk_q;

import java.util.ArrayList;

public class Kioskobj {
	public static ArrayList<Product> products = new ArrayList<>(); //상품들
	
	public static void productLoad() {
		products.add(new Product("아메리카노", 2500));       //상품 목록
		products.add(new Product("자바칩프라푸치노", 3500));
		products.add(new Product("자몽에이드", 3500));
	}
	
	
}
