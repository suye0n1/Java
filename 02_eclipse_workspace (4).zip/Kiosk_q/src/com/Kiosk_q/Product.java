package com.Kiosk_q;

public class Product {
	String name;
	int age;
	
	
	public Product(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
}
