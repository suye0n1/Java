package com.Kiosk_2;

public class buy {
	static void run_3() {
		
		System.out.println("카드 or 현금 (결제 방법을 입력하세요)");
		Kioskobj.cmd = Kioskobj.sc.next();
		
		loop:
			while(true) {
		switch(Kioskobj.cmd) {
		}
		if(Kioskobj.cmd.equals("카드")) {
			System.out.println("카드로 결제되었습니다.");
			break;
		}	else if(Kioskobj.cmd.equals("현금")) {
			System.out.println("현금으로 결제되었습니다.");
			break;
		}	else {
			System.out.println("잘못 입력하셨습니다.");
		}
		break loop;
	} 
	}
}
