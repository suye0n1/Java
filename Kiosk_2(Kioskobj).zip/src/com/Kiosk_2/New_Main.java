package com.Kiosk_2;



public class New_Main {

	public static void main(String[] args) {
		//코드 분리
		Kiosk_2 k = new Kiosk_2();
		k.run();
	
}
}
