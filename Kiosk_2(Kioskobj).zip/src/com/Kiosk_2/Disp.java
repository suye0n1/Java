package com.Kiosk_2;

import com.Util.Cw;

public class Disp {
//	일반 변수 /객체를 만들어야 쓸 수 있음
//	String x = "x"; 
	
//	static 변수 /	dot라는 변수를 어느 곳에서나 쓸 수 있게 됨(상수)
	//final 키워드를 붙이면 상수가 됨(이후 값을 바꾸지 못함) Final static String dot
	//상수 국룰 = 이름을 대문자로 사용 
//	정한 이름을 수정하려면: alt shift r
	//별을 DOT에 저장 
	static String DOT = "☆";
	
	public static void line() {
		for(int i=0; i<35; i++ ) {
			Cw.w(DOT); //DOT에 저장된 별을  출력 /String s에 DOT 저장됨
		}Cw.wn("");
	}
		
	public static void title() {
		Cw.wn("****************SYcafe*****************");
	}
	
}