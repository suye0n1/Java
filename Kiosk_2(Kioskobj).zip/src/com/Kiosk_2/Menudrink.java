package com.Kiosk_2;

import com.Util.Cw;

public class Menudrink {
	
	public static void run_1() {
		System.out.println("원하시는 메뉴를 입력해주세요");
		System.out.println("=====음료 리스트====");
		System.out.println("1번 메뉴");
		
		//Kioskobj 클래스에서 1-3번째 메뉴를 출력하려면
		//for문을 이용해서 출력해준다
		//products는 배열이므로 i<3를 조건으로 해준다(0번째에서 2번째까지 나오도록)
		//products에는 1-6개의 메뉴가 들어있는 상태
		for(int i=0; i<3; i++) {
			Cw.wn(Kioskobj.products.get(i).name+"는 "+Kioskobj.products.get(i).price+"원 입니다");
		}
		
		//Kioskobj.p1.info();
		//Kioskobj.p2.info();
		//Kioskobj.p3.info();
		
		loop_b: while (true) {
			System.out.println("[1.흑임자라떼/2.말차프라푸치노/3.자몽에이드/x:이전 메뉴]");
			//Kioskobj.cmd = Kioskobj.sc.next();를 써주지 않으면 무한 루프를 돌게 됨
			//[1.흑임자라떼/2.말차프라푸치노/3.자몽에이드/x:이전 메뉴] 이 메뉴가 계속 반복
			Kioskobj.cmd = Kioskobj.sc.next();
			
			switch (Kioskobj.cmd) {
			case "1":
				System.out.println("흑임자라떼");
				Kioskobj.x = new Product_1("흑임자라떼", 6000);
				Kioskobj.basket.add(Kioskobj.x);
				break;

			case "2":
				System.out.println("말차프라푸치노");
				Kioskobj.x = new Product_1("말차프라푸치노", 5500);
				Kioskobj.basket.add(Kioskobj.x);
				break;

			case "3":
				System.out.println("자몽에이드");
				Kioskobj.x = new Product_1("자몽에이드", 6500);
				Kioskobj.basket.add(Kioskobj.x);
				break;

			case "x":
				break loop_b;
			}
	}
}
}

