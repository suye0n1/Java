package com.Kiosk_2;

import java.util.ArrayList;
import java.util.Scanner;

public class Kioskobj {
	
	public static ArrayList<Product_1> basket = new ArrayList<Product_1>();
	public static ArrayList<Product_1> products = new ArrayList<Product_1>();
	
      	 //   public static Product_1 p1 = new Product_1("흑임자라떼", 6000);
		//	public static Product_1 p2 = new Product_1("말차프라푸치노", 5500);
		//	public static Product_1 p3 = new Product_1("자몽에이드", 6500);

		 //	public static Product_1 p4 = new Product_1("소금마카롱", 2000);
		//	public static Product_1 p5 = new Product_1("브라우니마카롱", 2500);
		//	public static Product_1 p6 = new Product_1("인절미마카롱", 2500);
	
	public static Product_1 x;
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	
	public static void productLoad() {
		products.add(new Product_1("흑임자라떼", 6000));
		products.add(new Product_1("말차프라푸치노", 5500));
		products.add(new Product_1("자몽에이드", 6500));

		products.add(new Product_1("소금마카롱", 2000));
		products.add(new Product_1("브라우니마카롱", 2500));
		products.add(new Product_1("인절미마카롱", 2500));
	}
	
	
}
