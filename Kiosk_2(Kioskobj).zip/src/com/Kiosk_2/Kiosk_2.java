package com.Kiosk_2;

public class Kiosk_2 {
	
	//코드 분리 Kioskobj클래스를 만들어줌 
		  	//basket배열리스트
	    //  public static ArrayList<Product_1> basket = new ArrayList<Product_1>();
	    //  public static Product_1 x;
		  	
		//	public static Product_1 p1 = new Product_1("흑임자라떼", 6000);
		//	public static Product_1 p2 = new Product_1("말차프라푸치노", 5500);
		//	public static Product_1 p3 = new Product_1("자몽에이드", 6500);

		//	public static Product_1 p4 = new Product_1("소금마카롱", 2000);
		//	public static Product_1 p5 = new Product_1("브라우니마카롱", 2500);
		//	public static Product_1 p6 = new Product_1("인절미마카롱", 2500);
//			public static을 써주면 어디서나 사용 가능
		//	public static Scanner sc = new Scanner(System.in);
		//	public static String cmd;
			
			void run() {
				Kioskobj.productLoad();
				Disp.line();
				Disp.title();
				Disp.line();
			
			loop_a: while (true) {
				System.out.println("주문하기");
				System.out.println("명령을 입력해주세요:[1.1번 메뉴/2.2번 메뉴/e:종료]");
				Kioskobj.cmd = Kioskobj.sc.next();

				switch (Kioskobj.cmd) {
				case "1":
					Menudrink.run_1();
					break;

				case "2":
					Menudessert.run_2();
					break;

				case "e":
					break loop_a;

				}
			}
			System.out.println("주문 종료");
			System.out.println("========주문 리스트=======");
		
			int count = Kioskobj.basket.size();
			System.out.println("개수는 "+count);

			
			int sum = 0;
			
			//향상된 for문
			for(Product_1 b:  Kioskobj.basket) {
				sum = sum + b.price;
				System.out.println(b.name);
			}
			
			//for문
		//	for (int i = 0; i <  Kioskobj.basket.size(); i = i + 1) {
		//		sum = sum +  Kioskobj.basket.get(i).price;
				
		//		System.out.println( Kioskobj.basket.get(i).name);
		//	}
				System.out.println("계산하실 금액은 "+sum+"입니다.");
				
		}
	}
	
