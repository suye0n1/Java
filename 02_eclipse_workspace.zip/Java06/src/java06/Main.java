package java06;

public class Main {
	public static void main(String[] args) {
		String  str1 = "Hello Java!";
		String  str2 = "안녕하세요! 반갑습니다.";
		System.out.println(str1.length());
		System.out.println(str2.length());
		
		System.out.println(str1.charAt(1)); //인덱스 번호
		System.out.println(str2.charAt(1));
		
		System.out.println(str1.indexOf('a'));
		System.out.println(str1.lastIndexOf('a'));
		
		
	}
}
