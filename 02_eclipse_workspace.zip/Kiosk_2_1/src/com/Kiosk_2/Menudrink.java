package com.Kiosk_2;

import com.Kiosk_2Product.Drink;
import com.Kiosk_2Product.Product_1;

public class Menudrink {
	
	public static void run_1() {
		System.out.println("원하시는 메뉴를 입력해주세요");
		System.out.println("=====1번 메뉴:음료 리스트====");
		
		//1-3 음료 메뉴 출력
	//	for(int i=0; i<3; i++) {
	//		Cw.wn(Kioskobj.products.get(i).name+" "+Kioskobj.products.get(i).price+"원");
	//	}
		
		
		//instanceof 사용해서 음료 리스트 불러오기
		//ArrayList에  products에 음료, 디저트 리스트가 들어가있음 이때 음료랑 디저트는 할아버지형(Product_1)으로 변환된 상태
		for(Product_1 p : Kioskobj.products) {
			if(p instanceof Drink) {
				//만약에 Product_1에는 없고 Drink에만 있는 객체(opt)가 있다면 ((Drink).p).opt)로 지정해주면 됨
				System.out.println(p.name+" "+p.price+"원");
			}
		}
		
		System.out.println("========================");
		
		loop_b: while (true) {
			System.out.println("[1.흑임자라떼/2.말차프라푸치노/3.자몽에이드/x:이전 메뉴]");
			Kioskobj.cmd = Kioskobj.sc.next();
			
			switch (Kioskobj.cmd) {
			case "1":
				System.out.println("흑임자라떼");
				//new Product_1에서 new Drink로 바꾸니 오류/import를 추가 안해서 오류 뜸
				Kioskobj.x = new Drink("흑임자라떼", 6000);
				//주문 추가
				//Order o = new Order(Kioskobj.products.get(0));
				//Kiskobj.basket.add(o);
				Kioskobj.basket.add(new Order(Kioskobj.products.get(0))); //주문 추가
				break;

			case "2":
				Opt.run_Opt();
				break;

			case "3":
				System.out.println("자몽에이드");
				Kioskobj.x = new Drink("자몽에이드", 6500);
				Kioskobj.basket.add(new Order(Kioskobj.products.get(2)));
				break;

			case "x":
				break loop_b;
			}
	}
}
}

