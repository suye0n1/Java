package com.Kiosk_2;

import java.util.ArrayList;
import java.util.Scanner;

import com.Kiosk_2Product.Dessert;
import com.Kiosk_2Product.Drink;
import com.Kiosk_2Product.Product_1;

public class Kioskobj {
	
	
	public static ArrayList<Order> basket = new ArrayList<>(); //주문 리스트
	//products에 0번째 흑임자라떼, 1번째 말차프라푸치노 2번째 자몽에이드.....5번째 인절미마카롱
	public static ArrayList<Product_1> products = new ArrayList<Product_1>();

	public static Product_1 x;
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	
	public static void productLoad() {
		products.add(new Drink("흑임자라떼", 6000));
		products.add(new Drink("말차프라푸치노", 5500));
		products.add(new Drink("자몽에이드", 6500));

		products.add(new Dessert("소금마카롱", 2000));
		products.add(new Dessert("브라우니마카롱", 2500));
		products.add(new Dessert("인절미마카롱", 2500));
	}
	
	
}
