package com.Kiosk_2;

import com.Kiosk_2Product.Product_1;

public class Order {

	//public을 주는 이유: name을 가져와야하기 때문에,,,??/그리고 Opt에도 써야하기 때문에,,,?
	public Product_1 selectedProduct_1;
	public String Opt; 
	
	public Order(Product_1 selectedProduct_1) {
		this.selectedProduct_1 = selectedProduct_1;
	}
	
	public Order(Product_1 selectedProduct_1, String Opt) {
		this.selectedProduct_1 = selectedProduct_1;
		this.Opt = Opt;
		
	}
	
	public void info() {
		
	}
	
	
	
	
	//옵션:초코칩/휘핑/x
	
	
	
	
}
