package com.Kiosk_2;

import com.Util.Cw;

public class Disp {

	static String DOT = "☆";
	
	public static void line() {
		for(int i=0; i<35; i++ ) {
			Cw.w(DOT); 
		}Cw.wn("");
	}
		
	public static void title() {
		Cw.wn("****************SYcafe*****************");
	}
	
}