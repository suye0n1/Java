package com.Kiosk_2;

import com.Kiosk_2Product.Drink;

public class Opt {
	
	//정적 멤버(static)는 인스턴스랑 다름 인스턴스는 객체를 만들어줘야 하지만 스테틱 멤버는 클래스명.멤버명만 써주면 됨
	//static을 써줘야 Menudrink에서 함수 실행이 가능함
	public static void run_Opt() {
//	loop: while(true) {
//		
//		System.out.println("Opt: 초코칩/휘핑/x(선택 안함)");
//		Kioskobj.cmd = Kioskobj.sc.next();
//		switch(Kioskobj.cmd) {
//		
//		case "초코칩":
//			System.out.println("초코칩을 선택했습니다.");
//			Kioskobj.x = new Drink("말차프라푸치노", 5800, "초코칩 추가");
//			Kioskobj.basket.add(Kioskobj.x);
//			break loop;
//			
//		case "휘핑":
//			System.out.println("휘핑을 선택했습니다.");
//			Kioskobj.x = new Drink("말차프라푸치노", 6000, "휘핑 추가");
//			Kioskobj.basket.add(Kioskobj.x);
//			break loop;
//			
//		case "x":
//			System.out.println("선택 안하셨습니다.");
//			Kioskobj.x = new Drink("말차프라푸치노", 5500);
//			Kioskobj.basket.add(Kioskobj.x);
//			break loop;
//			
//		}
			
		System.out.println("Opt: 1.초코칩 2.휘핑 3.x");
		Kioskobj.cmd = Kioskobj.sc.next();
		
		if(Kioskobj.cmd.equals("초코칩")) {
			System.out.println("초코칩을 선택했습니다.");
			Kioskobj.x = new Drink("말차프라푸치노", 5800, "초코칩 추가");
			Kioskobj.basket.add(new Order(Kioskobj.products.get(1),"초코칩"));
		} else if(Kioskobj.cmd.equals("휘핑")) {
			System.out.println("휘핑을 선택했습니다.");
			Kioskobj.x = new Drink("말차프라푸치노", 6000, "휘핑 추가");
			Kioskobj.basket.add(new Order(Kioskobj.products.get(1),"휘핑"));
		//	Kioskobj.basket.add(Kioskobj.x);
		} else if(Kioskobj.cmd.equals("x")) {
			System.out.println("선택 안하셨습니다.");
			Kioskobj.x = new Drink("말차프라푸치노", 5500);
			Kioskobj.basket.add(new Order(Kioskobj.products.get(1), "x"));
		//	Kioskobj.basket.add(Kioskobj.x);
		}	else {
			System.out.println("잘못 누르셨습니다.");
		}
				
		
	}
	
}
