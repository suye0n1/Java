package com.Kiosk_2;

public class Kiosk_2 {
	
			void run() {
				Kioskobj.productLoad();
				Disp.line();
				Disp.title();
				Disp.line();
			
			loop_a: while (true) {
				System.out.println("주문하기");
				System.out.println("명령을 입력해주세요:[1.1번 메뉴/2.2번 메뉴/e:종료]");
				Kioskobj.cmd = Kioskobj.sc.next();

				switch (Kioskobj.cmd) {
				case "1":
					Menudrink.run_1();
					break;

				case "2":
					Menudessert.run_2();
					break;

				case "e":
					break loop_a;

				}
			}
			System.out.println("주문 종료");
			//주문 리스트
			System.out.println("========주문 리스트=======");
		
			//1.개수
			int count = Kioskobj.basket.size();
			System.out.println("개수 "+count);

			
			int sum = 0;
			
			//2.주문한 거
			//향상된 for문
			//Order o: Kioskobj.basket에서 Kioskobj.basket에 계속 오류남
			//이유: public static ArrayList<Product_1> basket = new ArrayList<>();로 줬기 때문에
			//주문한 곳(Order)에서 배열 리스트를 만들어야됨 public static ArrayList<Order> basket = new ArrayList<>();로 줘야됨
			for(Order o: Kioskobj.basket) {
					sum = sum + o.selectedProduct_1.price;
					//주문 리스트에 Opt가 나오지 않음 그래서 o.Opt를 줬더니 나옴...왜...?
					//price는 Product_1에 있기 때문에 selectedProduct_1에서 가져와야하지만 Opt는 Order에 있기 때문에 바로 불러낼 수 있다? 
				System.out.println(o.selectedProduct_1.name+" Opt:"+o.Opt);
				}
			
				System.out.println("====================");
				
				//3.금액
				System.out.println("계산하실 금액은 "+sum+"입니다.");
				
		}
}
