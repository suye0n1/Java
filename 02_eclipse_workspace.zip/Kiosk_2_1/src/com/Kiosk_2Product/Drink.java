package com.Kiosk_2Product;

public class Drink extends Product_1 {
	
	 String opt; 
	 
	 public Drink(String name, int price) {
			super(name, price);
		}

	 public Drink(String name, int price, String opt) {
			super(name, price);
			this.opt = opt;
		}
	
	public void info() {
		System.out.println(name + " 가격" + price + "원  opt:"+opt);
		
	}
	
}
