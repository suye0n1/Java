package java01;

public class Main {
	
//		void는 return이 없는 함수
//		void info() 
	{
			
			
		}
	}
