package com.inherit;

//클래스를 상속할 때 extends 키워드 사용 GameObj가 부모 클래스 Character이 자식 클래스
public class Character extends GameObj {
	//String name;을 주지 않아도 사용 가능/부모 클래스에 있기 때문에
	int hp;
	int attack;
	
	// name을 생성
	// super() //부모를 가리키는 함수/맨 처음에 와야함/ 부모에 있는 변수를 실행할 수 있음
	public Character(String name, int hp, int attack) {
		super(name);
		this.hp = hp;
		this.attack = attack;
	}
}
