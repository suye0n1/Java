package com.inherit;

public class Item extends GameObj {
	
	int weight;
	int duration;
	
	
	public Item(String name,int weight, int duration) {
		super(name);
		this.weight = weight;
		this.duration = duration;

	}
	
	public Item(String name) {
		super(name);
		

	}


	

}
