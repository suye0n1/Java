package com.inherit;

import java.util.ArrayList;


public class Main {
	public static void main(String[] args) {
		//GameObj 할 Character 작 Item 아 Sword 손자
		Character elf = new Character("강아지", 100, 50);
		Item book = new Item("바둑이", 200, 120);
		Sword shortSword = new Sword("룰루랄라", 150, 5, 60);
		
		ArrayList<GameObj> gs = new ArrayList<>();
		gs.add(elf);
		gs.add(book);
		gs.add(shortSword);
		
		
		
		for(GameObj o : gs) {
			System.out.println(o.name);
			//ArrayList<GameObj>에 gs에 있는 것들을 불러오면 elf랑 book은 카페라떼가 나오고 shortSword만 바뀌어서 바닐라라떼가 나옴
			o.Drink();
		}
		
		((GameObj)elf).name = "강아지"; //1.((GameObj)elf).name을 보면 손자(elf)가 할아버지(GameObj)로 변신했기 때문에 
	//	((GameObj)c).weight = 1;  // 2.아버지(Item) 변수(weight)는 사용 못함
	//	((Item)elf).attack; //손자(elf)의 변수는 사용 불가능/아버지로 형 변환했기 때문에
   //	((Item)elf).weight = 1; //손자는 아버지로 형 변환했기 때문에 아버지 변수(weight) 사용 가능
		                     
		//각자 강제 형 변환 후, 할아버지 변수에 대입
		GameObj g1 = (GameObj)shortSword; //손자(shortSword)가 할아버지로 형 변환 후 대입
		
		//형 변환 없이 할아버지 변수에 대입해도 자동으로 형 변환이 일어남
		GameObj g2 = shortSword; //손자(shortSword)가 할아버지로 형 변환
		GameObj g3 = elf; //작은아버지(elf)가 할아버지로 형 변환 
		
	//	g2.weight; //자기 클래스의 변수는 못쓰게 됨
	//	g3.hp;     //자기 클래스의 변수는 못쓰게 됨
		
		ArrayList<GameObj> gf = new ArrayList<>();
		gf.add(g2); //배열에 넣으면 이 경우에도 자동 형 변환 일어남
		gf.add(g3);
		
		//자기 클래스꺼 쓰려면 원형으로 돌아가야하기 때문에 다시 형 변환을 해준다.
		//자기 클래스 함수도 쓸 수 있음
		Sword s = (Sword)g2;
		
		//A instanceof B : A의 원형이 B인지 검사하는 명령 
		if(g2 instanceof Sword) {
			System.out.println("얘 원래 검임");
		}
		if(g3 instanceof Character) {
			System.out.println("얘 원래 케릭임");
		}
		
		for(GameObj o : gs) {
			System.out.println(o.name);
			if(o instanceof Sword) {
				System.out.println(o.name + "의 공격력은 "+((Sword)o).attack);
			}
			if(o instanceof Character) {
				System.out.println(o.name + "의 체력은 "+((Character)o).hp);
			}
		}
		
		int n = 1 + ((Sword)gs.get(2)).attack;
		System.out.println("공격력"+n);

		shortSword.Drink();
		
		
	//	가족끼리만 형 변환 가능
		
	//	Character elf = new Character("강아지"); //오류 발생 Character는 name이 주어져있지 않음
	//그래서 Character 클래스에 name을 만들어줌
	//	Character elf = new Character("강아지", 100, 50);
	//	elf.name = "1";
	//	elf.hp = 100;
	//	elf.info();
		
	//	Item book = new Item("바둑이", 200, 120);
	//	book.weight = 200;
	//	book.name = "돌돌이";
	//	book.duration = 120;
	//	book.info();
		
		//Sword의 부모 클래스는 Item/GameObj에 있는 것도 사용 가능
	//	Sword shortSword = new Sword("룰루랄라", 150, 5, 60);
	//	shortSword.name = "단검";
	//	shortSword.attack = 150;
	//	shortSword.weight = 5;
		
		
	}
}
