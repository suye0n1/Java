package com.inherit;

//부모 클래스 Item
public class Sword extends Item {

	int attack;
	
	//super(name)로 하면 오류가 남 Sword의 부모 클래스는 Item이므로
	//super에 public Item(String name,int weight, int duration)에 나열되어 있는 데로 써줘야함
	//그러나 Item 클래스(Sword의 부모 클래스)에 
	//public Item(String name) {
	//super(name);
	//}
	//하나 더 생성을 해주면 super(name);로 설정해도 됨
	//즉, 손자(Sword)는 아버지(Item) 객체 사용 가능하지만 할아버지(GameObj)의 객체 사용 안됨
	public Sword(String name, int attack, int weight, int duration) {
		super(name);
		this.attack = attack;
		
		
	}
//	오버 라이딩 : 함수 기능 변경 (조건:1.함수 이름, 매개 변수 바꾸는 거 불가능 2.함수 내용만 바꿀 수 있음)
//	GameObj(할)에서 함수를 선언(public void Drink(){System.out.println("카페라떼"))하고 
//	Sword(손)에서 함수 내용을 바꿔주면((public void Drink(){System.out.println("바닐라라떼")) 
//	실행했을 때(shortSword.Drink();) 바닐라라떼가 나옴
	public void Drink() {
		System.out.println("바닐라라떼");
	}

	
}
