package com.inherit_1;

public class inheritance {
		String name;
		String adress;
		int age;
		String ride;
		
		
		void info() {
			System.out.println("이름:"+name);
			System.out.println("나이:"+age);
			System.out.println("주소:"+adress);
		}
		
}
