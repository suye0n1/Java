package com.inherit_1;

public class human extends inheritance {
	int workID;
	
}
