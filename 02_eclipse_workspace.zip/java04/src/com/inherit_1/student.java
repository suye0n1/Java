package com.inherit_1;

public class student extends inheritance {
	int studentID;
	
}
