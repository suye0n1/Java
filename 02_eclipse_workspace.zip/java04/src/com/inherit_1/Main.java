package com.inherit_1;

public class Main {

	public static void main(String[] args) {
			student x = new student();
			x.name = "HY";
			x.age = 19;
			x.adress = "사동";
			x.studentID = 21;
			x.info();
			System.out.println("studentID:"+x.studentID);
			
			human y = new human();
			y.name = "JY";
			y.age = 30;
			y.adress = "해양동";
			y.workID = 19;
			y.info();
			System.out.println("workID:"+y.workID);
			
			
	}

}
