package java03;


public class Main {
	public static void main(String[] args) {

//			Scanner sc = new Scanner(System.in);
//			String cmd  = sc.next();
//			System.out.println(cmd);

		// 내가 선택한 번호
		int x[] = new int[] { 31, 20, 5, 13, 7, 41 };
		for (int i = 0; i < 6; i = i + 1) {
			System.out.println(x[i]);
		}
//		숫자 한번에 나오게 하려면

//		System.out.println(Arrays.toString(x));

//			랜덤 번호
		int i[] = new int[] { 0, 0, 0, 0, 0, 0 };

//			첫 번째 번호
		i[0] = (int) (Math.random() * 45 + 1);
		System.out.println(i[0]);

//			두 번째 번호/첫번째랑 일치하면 번호 다시 뽑기

		while (true) {
			i[1] = (int) (Math.random() * 45 + 1);

			if (i[0] != i[1]) {
				System.out.println(i[1]);
				break;
			}

		}
//			세 번째 번호/ 1,2 일치하면 번호 다시 뽑기

		while (true) {
			i[2] = (int) (Math.random() * 45 + 1);

			if (i[2] != i[0] && i[2] != i[1]) {
				System.out.println(i[2]);
				break;
			}

		}
//			네 번째 번호/ 1,2,3 일치하면 번호 다시 뽑기

		while (true) {
			i[3] = (int) (Math.random() * 45 + 1);

			if (i[3] != i[0] && i[3] != i[1] && i[3] != i[2]) {
				System.out.println(i[3]);
				break;
			}

		}
//				다섯 번째 번호/ 1,2,3,4 일치하면 번호 다시 뽑기

		while (true) {
			i[4] = (int) (Math.random() * 45 + 1);

			if (i[4] != i[0] && i[4] != i[1] && i[4] != i[2] && i[4] != i[3]) {
				System.out.println(i[4]);
				break;
			}
		}

//				여섯 번째 번호/ 1,2,3,4.5 일치하면 번호 다시 뽑기

		while (true) {
			i[5] = (int) (Math.random() * 45 + 1);

			if (i[5] != i[0] && i[5] != i[1] && i[5] != i[2] && i[5] != i[3] && i[5] != i[4]) {
				System.out.println(i[5]);
				break;
			}
		}
//			컴퓨터의 6개의 숫자랑 내꺼랑 비교해서 몇개가 일치하는 지
//		int a = 0;
//			x의 0
//		if (x[0] == i[0]) {
//			a = a + 1;
//		}
//
//		if (x[0] == i[1]) {
//			a = a + 1;
//		}
//
//		if (x[0] == i[2]) {
//			a = a + 1;
//		}
//
//		if (x[0] == i[3]) {
//			a = a + 1;
//		}
//
//		if (x[0] == i[4]) {
//			a = a + 1;
//		}
//
//		if (x[0] == i[5]) {
//			a = a + 1;
//		}

//			x의 1
//		if (x[1] == i[0]) {
//			a = a + 1;
//		}
//
//		if (x[1] == i[1]) {
//			a = a + 1;
//		}
//
//		if (x[1] == i[2]) {
//			a = a + 1;
//		}
//
//		if (x[1] == i[3]) {
//			a = a + 1;
//		}
//
//		if (x[1] == i[4]) {
//			a = a + 1;
//		}
//
//		if (x[1] == i[5]) {
//			a = a + 1;
//		}
//			x의 2
//		if (x[2] == i[0]) {
//			a = a + 1;
//		}
//
//		if (x[2] == i[1]) {
//			a = a + 1;
//		}
//
//		if (x[2] == i[2]) {
//			a = a + 1;
//		}
//
//		if (x[2] == i[3]) {
//			a = a + 1;
//		}
//
//		if (x[2] == i[4]) {
//			a = a + 1;
//		}
//
//		if (x[2] == i[5]) {
//			a = a + 1;
//		}
//			x의 3
//		if (x[3] == i[0]) {
//			a = a + 1;
//		}
//
//		if (x[3] == i[1]) {
//			a = a + 1;
//		}
//
//		if (x[3] == i[2]) {
//			a = a + 1;
//		}
//
//		if (x[3] == i[3]) {
//			a = a + 1;
//		}
//
//		if (x[3] == i[4]) {
//			a = a + 1;
//		}
//
//		if (x[3] == i[5]) {
//			a = a + 1;
//		}

//			x의 4
//		if (x[4] == i[0]) {
//			a = a + 1;
//		}
//
//		if (x[4] == i[1]) {
//			a = a + 1;
//		}
//
//		if (x[4] == i[2]) {
//			a = a + 1;
//		}
//
//		if (x[4] == i[3]) {
//			a = a + 1;
//		}
//
//		if (x[4] == i[4]) {
//			a = a + 1;
//		}
//
//		if (x[4] == i[5]) {
//			a = a + 1;
//		}
//			x의 5
//		if (x[5] == i[0]) {
//			a = a + 1;
//		}
//
//		if (x[5] == i[1]) {
//			a = a + 1;
//		}
//
//		if (x[5] == i[2]) {
//			a = a + 1;
//		}
//
//		if (x[5] == i[3]) {
//			a = a + 1;
//		}
//
//		if (x[5] == i[4]) {
//			a = a + 1;
//		}
//
//		if (x[5] == i[5]) {
//			a = a + 1;
//		}
//		System.out.println(a);
		int a = 0;
//	몇 개가 일치하는지 반복문으로 처리
	for(int k=0; k<6; k=k+1) {
		for(int j=0; j<6; j=j+1) {
			if(x[k] == i[j]) {
				a = a + 1;
			}
		}
		System.out.print("맞은 개수:"+a);
	}
//	몇 개 맞췄는지에 따라서 등수 출력
	
	switch(a) {
	case 0:
	case 1:
	case 2:
		System.out.println("꽝!!! 다음 기회에");
		break;	
	}
}
}
