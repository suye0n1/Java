package java05;

public class Main {
	public static void main(String[] args) {
		String cat = "고양이"; //힙 <"고양이"> 100번지가 만들어짐
		String cat2 = "고양이"; //위의 <"고양이"> 100번지를 다ㅏ시 사용
		
		System.out.println(System.identityHashCode(cat)); //주소가 나오는데 cat과 cat2가 같음
		System.out.println(System.identityHashCode(cat2));
		
		
		
		if(cat == cat2) {
			System.out.println("같음");
		}
		
		String dog = new String("강아지"); //힙 <"강아지"> 200번지 생성
		String dog2 = new String("강아지"); //힙 <"강아지"> 300번지 생성
		if(dog == dog2) {
			System.out.println("같음");
		} else {
			System.out.println("다름");
		}
		
		
	}
}
