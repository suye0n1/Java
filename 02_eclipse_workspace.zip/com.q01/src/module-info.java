/**
 * 
 */
/**
 * @author GDJ 59
 *
 */
module com.q01 {
}