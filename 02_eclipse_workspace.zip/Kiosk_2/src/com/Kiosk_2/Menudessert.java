package com.Kiosk_2;

import com.Util.Cw;

public class Menudessert {
	
	public static void run_2() {
		System.out.println("원하시는 메뉴를 입력해주세요");
		System.out.println("====디저트 리스트====");
		System.out.println("디저트 메뉴");
		
		//4-6 메뉴 출력
		for(int i=4; i<7; i++) {
			Cw.wn(Kioskobj.products.get(i).name+" "+Kioskobj.products.get(i).price+"원");
		}
		
	//	Cw.wn("5."+Kioskobj.products.get(4).name+" "+Kioskobj.products.get(4).price+"원");
	//	Cw.wn("6."+Kioskobj.products.get(5).name+" "+Kioskobj.products.get(5).price+"원");
	//	Cw.wn("7."+Kioskobj.products.get(6).name+" "+Kioskobj.products.get(6).price+"원");
		System.out.println("=================");
		
//		2번 메뉴
		loop_c: while (true) {
			
			System.out.println("1.소금마카롱 2.브라우니마카롱 3.인절미마카롱 c:장바구니 y:이전 메뉴");
			Kioskobj.cmd = Kioskobj.sc.next();
			
			switch (Kioskobj.cmd) {
			case "1":
				System.out.println("소금마카롱");
				Kioskobj.x = new Product_1("소금마카롱", 2000);
				Kioskobj.basket.add(Kioskobj.x);
				break;

			case "2":
				System.out.println("브라우니마카롱");
				Kioskobj.x = new Product_1("브라우니마카롱", 2500);
				Kioskobj.basket.add(Kioskobj.x);
				break;

			case "3":
				System.out.println("인절미마카롱");
				Kioskobj.x = new Product_1("인절미마카롱", 2500);
				Kioskobj.basket.add(Kioskobj.x);
				break;
			
			//장바구니 내역
			case "c":
				
			case "y":
				break loop_c;
			}
		
	}
}
}
