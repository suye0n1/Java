package com.Kiosk_2;

import com.Util.Cw;

public class Menudrink {
	
	public static void run_1() {
		System.out.println("원하시는 메뉴를 입력해주세요");
		System.out.println("=====음료 리스트====");
		System.out.println("음료 메뉴");
		
		
		//1-3 메뉴 출력
		for(int i=0; i<4; i++) {
			Cw.wn(Kioskobj.products.get(i).name+" "+Kioskobj.products.get(i).price+"원");
		}
		
		System.out.println("=================");
		
		loop_b: while (true) {
			
			System.out.println("1.흑임자라떼 2.말차프라푸치노 3.자몽에이드 c:장바구니 x:이전 메뉴");
			
			Kioskobj.cmd = Kioskobj.sc.next();
			
			switch (Kioskobj.cmd) {
			case "1":
				System.out.println("흑임자라떼");
				Opthotice.run_1_1();
				break;

			case "2":
				System.out.println("말차프라푸치노");
				Kioskobj.x = new Product_1("말차프라푸치노", 5500);
				Kioskobj.basket.add(Kioskobj.x);
				break;

			case "3":
				System.out.println("자몽에이드");
				Kioskobj.x = new Product_1("자몽에이드", 6500);
				Kioskobj.basket.add(Kioskobj.x);
				break;
			
		    //장바구니 내역
			case "c":
		//		int i;
		//		for(i=0 i<Kioskobj.basket.size; )
			case "x":
				break loop_b;
			}
	}
}
}

