package com.Kiosk_2;

public class Opthotice {
	static void run_1_1() {
		System.out.println("흑임자라떼를 선택하셨습니다./ m:메뉴로 돌아가기");
		System.out.println("1.Hot 2.Ice (선택하세요)");
		
		loop: 
		while(true) {
			
			Kioskobj.cmd = Kioskobj.sc.next();
			switch(Kioskobj.cmd) {
			case "1":
				System.out.println("Hot을 선택했습니다.");
				Kioskobj.x = new Product_1("흑임자라떼", 6000);
				Kioskobj.basket.add(Kioskobj.x);
				break loop;
			case "2":
				System.out.println("Ice를 선택했습니다");
				Kioskobj.x = new Product_1("흑임자라떼", 6500);
				Kioskobj.basket.add(Kioskobj.x);
				break loop;
			
			case "m":
				System.out.println("메뉴로 돌아가기");
				break loop;
			} 
		}
	}
}
