package com.Kiosk_2;

public class Kiosk_2 {
	
			void run() {
				Kioskobj.productLoad();
				Disp.line();
				Disp.title();
				Disp.tel();
			
			loop_a: while (true) {
				System.out.println("주문하기: 명령을 입력해주세요");
				System.out.println("1.음료 메뉴 2.디저트 메뉴 e:주문 종료");
				Kioskobj.cmd = Kioskobj.sc.next();

				switch (Kioskobj.cmd) {
				case "1":
					Menudrink.run_1();
					break;

				case "2":
					Menudessert.run_2();
					break;

				case "e":
					break loop_a;

				}
			}
			System.out.println("주문 종료");
			System.out.println("========주문 리스트=======");
		
			int count = Kioskobj.basket.size();
			System.out.println("개수는 "+count);

			
			int sum = 0;
			
			//향상된 for문
			for(Product_1 b:  Kioskobj.basket) {
				sum = sum + b.price;
				System.out.println(b.name+" 가격: "+b.price);
			}
			
				System.out.println("계산하실 금액은 "+sum+"입니다.");
				System.out.println("======================");
				System.out.println("주문하시겠습니까?(네/아니오)");
				
				Kioskobj.cmd = Kioskobj.sc.next();
				
				//이곳에 loop를 주면 실행을 멈추기 때문에 "네" 했을 때 다시 실행되려면 loop를 주면 안 됨..
				while(true) {
	
				if(Kioskobj.cmd.equals("네")) {
					buy.run_3();
					//break문을 써주지 않으면 멈추지 않기 때문에 
					//"네"라고 한 후 카드 or 현금을 선택할 때 카드를 선택하면 else구문이 작동되어 "다시 입력하세요"라는 문구가 뜬다
					break;
				} else if(Kioskobj.cmd.equals("아니오")) {
					run();
					break;
				}	else {
					System.out.println("다시 입력하세요.");
					Kioskobj.cmd = Kioskobj.sc.next();
				}

				}
				
				System.out.println("주문을 종료합니다.");
				
		}
	}
