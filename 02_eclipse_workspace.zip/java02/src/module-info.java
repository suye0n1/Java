/**
 * 
 */
/**
 * @author GDJ 59
 *
 */
module java02 {
}