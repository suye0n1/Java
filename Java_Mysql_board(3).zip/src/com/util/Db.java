package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.board.Board;

public class Db {

	public static Connection con = null;
	public static Statement st = null;
	public static ResultSet result = null;
	
	public static void dbInit() {
		try {
			// (1/n) 디비 접속 정보 넣어서 접속하기
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/board", "root", "root");
			// (2/n) Statement 객체 얻어오기.
			st = con.createStatement();	// Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열 수있다.
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	public void dbExecuteQuery(String query) {
		try {
			
		result = st.executeQuery(query);
			
			while (result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String name = result.getString("p_name");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				System.out.println(name);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}		
	public static void dbExecuteUpdate(String query) {
		try {
			// (3/n) Statement 객체의 executeUpdate함수에 sql문 실어서 디비에서 실행되게 하기
			int resultCount = st.executeUpdate(query); // 이거 하는 순간 디비에 sql(쿼리) 날아감. (디비에 반영됨)
			System.out.println("처리되었습니다.("+resultCount+")");
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}	
	

		
	
	
	//ctrl + h 
	public static void dbPostCount() {	
		try {
			result = st.executeQuery("select count(*) from board where b_ori_num is null");
			result.next();
			String count = result.getString("count(*)");
			System.out.println("글 개수는 "+count+"개 입니다");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void dbReCount() {	
		try {
			result = st.executeQuery("select count(*) from board where b_ori_num is not null");
			result.next();
			String count = result.getString("count(*)");
			System.out.println("댓글 개수는 "+count+"개 입니다");
		} catch (SQLException e) {
			e.printStackTrace();
		}	Cw.wn();
	}
	
	
	//페이지 수를 구하기 위해 글 개수를 구해줌
	public static int getPostCount() {
		String count = "";
		try {
			result = st.executeQuery("select count(*) from board where b_ori_num is null");
			result.next();
			count = result.getString("count(*)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int intcount = Integer.parseInt(count);
		return intcount;
	}
	
//	public static int getPostCountSearch(String searchWord) {
//		String count = "";
//		try {
//			String a = "select count(*) from board where b_ori_num is null"
//					+
//					" and title like '%"+searchWord+"%'";
//			//System.out.println(a);
//			Db.result = Db.st.executeQuery(a);
//			Db.result.next();
//			count = Db.result.getString("count(*)");
//			Cw.wn("글 수:"+count);
//		} catch (Exception e) {
//		}
//		int intCount = Integer.parseInt(count);
//		return intCount;
//	}
		
		public static boolean login(String id, String pw) {
			
			String count = "";
			
			try {
				//select count(*) from member where s_id= and s_pw=;
				Db.result = Db.st.executeQuery(
						"select count(*) from s_member where s_id='"
						+id+
						"' and s_pw='"
						+pw+
						"'"
						);
				Db.result.next();
				count = Db.result.getString("count(*)");
				Cw.wn("회원 아이디 "+id+" ("+count+")");
			} catch (Exception e) { e.printStackTrace();
			}
			if(count.equals("1")) {
				Cw.wn("로그인 성공");
				return true;
				//로그인 성공
			}else {
				Cw.wn("로그인 실패");
				return false;	//로그인 실패
			}
			
		}
	

	}


