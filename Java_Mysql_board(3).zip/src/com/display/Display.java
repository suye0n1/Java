package com.display;

public class Display {

	private static String TITLE_1 = "♥";
	private static String TITLE_2 = "FAMILY BOARD";
	
		static public void title() {			
		System.out.print(TITLE_1);
		System.out.print(TITLE_2);
		System.out.print(TITLE_1);
	}
	
//	static private String MAIN_MENU_BAR = "★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★";
	static private String MAIN_MENU	 	= "♣ m:글 메뉴 s:회원가입 i:로그인  0:관리자  e:프로그램 종료 ♣";
//	public static String b_reply = "7.댓글 보기 8.댓글 수정 e:프로그램 종료 0.관리자"; 
	
	static public void MainMenu() {
	//	System.out.println("MENU");
		System.out.println(MAIN_MENU);
	//	System.out.println("☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆");
	//	System.out.println(b_reply);
	//	System.out.println(MAIN_MENU_BAR);
		
	}
	
	public static void space(int c) {
		for(int i=0;i<c;i++) {
			System.out.print(" ");
		}
	
	}
	
}
