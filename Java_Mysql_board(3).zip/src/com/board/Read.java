package com.board;

import java.sql.SQLException;

import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class Read {
	public static void run_r() {
		
		System.out.println("☆글 읽기☆");
		String readNo =Ci.r("읽을 글 번호를 입력하세요");
		
		try {
			Db.result = Db.st.executeQuery("select * from board where no ="+readNo);
			Db.result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
			String title = Db.result.getString("title");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String content = Db.result.getString("content");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String id = Db.result.getString("id");
			
			System.out.println("===================");
			System.out.println("글제목: "+title);
			System.out.println("작성자: "+id);
			System.out.println("글내용: "+content);
			System.out.println("===================");
			
		//	readNo(매개변수)를 넣어줘서 b_ori_num으로 넘김 readNo이 1번이면 b_ori_num에 1번 저장
			String re = Ci.r("댓글을 입력하시겠습니까?(y or n)");
			if(re.equals("y")) {
			run_re_w(readNo);
			} else {
				Cw.wn("메뉴로 돌아가기");
				Board.run();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	//
	public static void run_re_w(String b_ori_num) {
		//댓글 작성
				String b_re_text = Ci.rl("댓글을 입력하세요");
			//	String sql = "select * from board where No="+b_ori_num;
				Db.dbExecuteUpdate("insert into board (dt,b_ori_num,b_re_text) values(now(),"+b_ori_num+",'"+b_re_text+"')");
//				try {
//					Db.result = Db.st.executeQuery("sql");
//					Db.result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
//					String re = ("insert into board (b_ori_num,b_re_text)"
//							+" values ('"+b_ori_num+"','"+b_re_text+"')");
//					System.out.println(re);
//					Db.st.executeUpdate(re);
//					System.out.println("댓글이 작성되었습니다.");
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
}
}


