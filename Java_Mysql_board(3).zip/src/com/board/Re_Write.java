package com.board;

import java.sql.SQLException;

import com.util.Ci;
import com.util.Db;

public class Re_Write {
	public static void run() {
		System.out.println("☆댓글 쓰기☆");
		//b_re_count,b_ori_num,b_re_text
		String b_ori_num = Ci.rl("글 번호를 입력하세요");
		String b_re_text = Ci.rl("내용을 입력하세요");
		
		try {
			String re = ("insert into board (b_ori_num,b_re_text)"
					+" values ('"+b_ori_num+"','"+b_re_text+"')");
			//로그 남기기
			System.out.println(re);
			Db.st.executeUpdate(re);
			System.out.println("댓글이 작성되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
