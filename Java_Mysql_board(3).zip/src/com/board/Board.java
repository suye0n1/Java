package com.board;

import com.member.Login;
import com.site.Site_main;
import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class Board {
	static private String loginedId = null;
	
		public static void run() {
			
			loop:
				while(true) {
					
//					String cmd = Ci.r("명령을 입력하세요");
					
					if (loginedId == null) {
						Cw.wn("게시판 이용이 불가능합니다(로그인 필수) / 다시 입력하세요~!");
						Login.run();
					
						
					} else {
						System.out.println("반갑습니다."+ loginedId+"회원님 게시판 이용이 가능합니다.");
						Cw.wn();
						Cw.wn("1.글 리스트 2.글 읽기 3.글 쓰기 4.글 삭제 5.글 수정 6.글 검색");
						Cw.wn("7.댓글 보기 8.댓글 수정 x.이전 메뉴");
						Cw.wn("");
						String cmd_1 = Ci.r("명령을 입력하세요");
						switch(cmd_1) {
						
						case "1":
							List.run();
							break;
						
						case "2":
							Read.run_r();
					
							break;
							
						case "3":
							Write.run();
							break;
							
						case "4":
							Delete.run();
							break;
							
						case "5":
							Edit.run();
							break;
						case "6": //글 검색
							List.search();
							break;
							
						case "7": //댓글 보기
							Db.dbReCount(); //댓글 수
							Reply.run();
							break;
							
						case "8": //댓글 수정
							Re_Edit.run();
							break;
							
						case "x": //이전 메뉴
							return;
							
						default:
							Cw.w("잘못 입력하셨습니다.");
							break loop;
					}
					}
					
					
						
				}
		}
	}
		

