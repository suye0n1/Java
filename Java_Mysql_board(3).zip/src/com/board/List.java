package com.board;

import java.sql.SQLException;

import com.display.Display;
import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class List {

	public static final int PER_PAGE = 5;

	static int startIndex = 0; // 현재 페이지의 첫 글 인덱스
	static int currentPage = 1; // 현재 페이지
	static int totalPage = 0; // 전체 페이지
	static int count = 0; // 페이지 개수
	static String cmd; // 입력

	public static void run() {

		// 전체 페이지 수 구해서 5로 나눈 나머지가 0 이상인 경우
		if (Db.getPostCount() % PER_PAGE > 0) {
			totalPage = Db.getPostCount() / PER_PAGE + 1;
		} else {
			totalPage = Db.getPostCount() / PER_PAGE;
		}

		// 페이지 입력
		while (true) {
			cmd = Ci.r("페이지 번호를 입력하세요(x:이전 메뉴)");
			Cw.wn();

			if (cmd.equals("x")) {
				break;
			}

			currentPage = Integer.parseInt(cmd);

			if (currentPage > totalPage || currentPage < 1) {
				Cw.wn("페이지 범위에 맞는 값을 넣어주세요");
				continue; // while문 다시 돌리기
			}

			startIndex = (currentPage - 1) * PER_PAGE; // 페이지의 첫 인덱스를 계산해서 저장
//	select count(*) from board where b_ori_num is null; /댓글 제외시키기
			String sql = "select * from board where b_ori_num is null limit " + startIndex + "," + PER_PAGE;
			System.out.println("☆글 리스트☆");
			Db.dbPostCount();
//	String sql = "select * from board limit "+startIndex+","+PER_PAGE;

			try {
				// select * from board limit 0,3; (첫페이지, 세개)

				// Cw.wn("전송한sql문:"+sql);
				Db.result = Db.st.executeQuery(sql);

				// result = st.executeQuery("select * from board");
				while (Db.result.next()) {
					// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					String no = Db.result.getString("no");
					String title = Db.result.getString("title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
					String id = Db.result.getString("id");
					String dt = Db.result.getString("dt");
					String hits = Db.result.getString("hits");
					String content = Db.result.getString("content"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)

					System.out.println("================================================");
					System.out.println("글 번호: " + no);
					System.out.println("글 제목: " + title);
					System.out.println("작성자: " + id);
					System.out.println("작성 시간: " + dt);
					System.out.println("조회수: " + hits);
					System.out.println("글 내용: " + content);
					System.out.println("================================================");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	// 처음 페이지 글 리스트
	public static void list() {

		if (Db.getPostCount() % PER_PAGE > 0) {
			totalPage = Db.getPostCount() / PER_PAGE + 1;
		} else {
			totalPage = Db.getPostCount() / PER_PAGE;
		}
		Display.space(55);
		Cw.wn("총 " + totalPage + "페이지");

		startIndex = (currentPage - 1) * PER_PAGE; // 첫페이지 인덱스 구하기

		// "select * from board where b_ori_num is null limit 0,5; PER_PAGE니깐 5개 출력
		String list = "select * from board where b_ori_num is null limit " + startIndex + "," + PER_PAGE;

		try {
			Db.result = Db.st.executeQuery(list);

			while (Db.result.next()) {

				String no = Db.result.getString("no");
				String title = Db.result.getString("title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String id = Db.result.getString("id");
				String dt = Db.result.getString("dt");
				String hits = Db.result.getString("hits");
				// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)

				System.out.println("============================================================================");
				System.out.print("글 번호:" + no);
				System.out.print(" ");
				System.out.print("글 제목:" + title);
				System.out.print(" ");
				System.out.print("작성자:" + id);
				System.out.print(" ");
				System.out.print("작성 시간:" + dt);
				System.out.print(" ");
				System.out.println("조회수: " + hits);
				System.out.println("============================================================================");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// 6.검색어를 입력받으면 리스트 츨력
	public static void search() {
		String cmd;
		cmd = Ci.rl("검색어를 입력하세요(x:나가기)");
		if (cmd.equals("x")) {
			return;
		} else {
			searchList(cmd);
		}
	}

	// 리스트-검색 처리
	public static void searchList(String searchWord) {

		String sql = "select * from board where b_ori_num is null" + " and title like '%" + searchWord + "%'";

		try {
			Db.result = Db.st.executeQuery(sql);
			while (Db.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String no = Db.result.getString("no");
				String title = Db.result.getString("title");
				String id = Db.result.getString("id");
				String datetime = Db.result.getString("dt");
				System.out.println("==============================================================");
				Cw.wn("글 번호:" + no + " 글 제목:" + title + " 작성자:" + id + " 작성 시간:" + datetime);
				System.out.println("==============================================================");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
