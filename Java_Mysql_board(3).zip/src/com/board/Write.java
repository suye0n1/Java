package com.board;

import java.sql.SQLException;

import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class Write {
	public static void run() {
		
			System.out.println("☆글 작성☆");
			String title = Ci.rl("제목을 입력하세요");
			String id = Ci.rl("작성자 id를 입력하세요");
			String content = Ci.rl("글내용을 입력하세요");
			
			try {
				Db.st.executeUpdate("insert into board (title, id, dt, content)"
						+" values ('"+title+"','"+id+"',now(),'"+content+"')");
				Cw.wn("글등록 완료");
			} catch (SQLException e) {
				e.printStackTrace();
			}		
		}
	}