package com.site;

import com.board.Board;
import com.board.List;
import com.display.Display;
import com.member.Login;
import com.member.Sign_up;
import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class Site_main {
	static private String loginedId = null;

	public static void run() {
		Db.dbInit();	
		Display.title();
		List.list();
		Display.MainMenu();

		//오류: 1번은 2번에 대한 명령만 적용됨 1번 cmd가 3번의 명령 적용x
	//	String cmd = Ci.r("명령을 입력하세요"); //1

//		if(cmd.equals("s")) { //2
//			Sign_up.run(); 
//		}
		
		
		String cmd = Ci.r("명령을 입력하세요");
		
		loop: while (true) { //3
			
			//m: 로그인 검사(로그인하면 게시판 진행. 가입하기도 선택가능하게. 로그임
//			if (loginedId == null) {
//				cmd = Ci.r("게시판 이용이 불가능합니다(로그인 필수) / 명령을 다시 입력하세요");
//				
//			} else {
//				cmd = Ci.r(loginedId + " 고객님 반갑습니다. 게시판 이용이 가능합니다.");
//			}
			
			switch (cmd) {
			case "m":
				Board.run();
				break;
			case "s":	// 회원가입
				Sign_up.run(); 
				break;
			case "i":	//로그인
				Login.run();
				break;
			case "o": // 로그아웃
				if (loginedId != null) {
					Cw.wn("로그아웃 되었습니다.");
					loginedId = null;
				}
				break;
			case "0": // 관리자
				System.out.println("☆관리자☆");
			case "e":
				System.out.println("☆프로그램이 종료되었습니다.☆");
				break loop;

			default:
				Cw.wn("잘못 입력하셨습니다.");
			}
			break loop;
		}
	}
}
