package com.member;


import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class Login {
	
	/* 로그인 처리 */
//	static private String cmd = "";
	
	static public String run() {
		
		Cw.wn("◎로그인◎");
		String id="";
		String pw="";
		
		while(true) {
			id=Ci.r("아이디");
			if(id.length()>0) {
				break;
			}else {
				Cw.wn("잘못 입력하셨습니다.");
			}
		}
		
		while(true) {
			pw=Ci.r("비밀번호");
			if(pw.length()>0) {
				break;
			}else {
				Cw.wn("잘못 입력하셨습니다.");
			}
		}
		
		//id,pw를 db에 저장 
		if(Db.login(id,pw)) {
			return id;
		} else {
			Cw.wn("로그인 실패");
			return null;
		}
	
	} 
}
