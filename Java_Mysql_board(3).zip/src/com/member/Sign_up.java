package com.member;

import com.site.Site_main;
import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class Sign_up {
	// 회원가입
				public static void run() {
					Cw.wn("◎회원가입 페이지◎");
					Cw.wn("c:14세 미만 회원가입 g:14세 이상 회원가입  x:이전 메뉴");
					Cw.wn("명령을 입력하세요:");
					String id = "";
					String pw = "";
					String cmd = "";
					// while문이 두 개, 아이디 while문 실행 후 이래 비밀번호 while문 실행

					//회원가입
					while(true) {	
							cmd = Ci.r();
					switch (cmd) {
				
						//14세 미만
						case "c":
							Cw.wn("14세 미만 회원 가능");
							//아이디
							
							while(true) {
							id = Ci.r("아이디");
							if (id.length() > 0) {
								break;
							} else {
								Cw.wn("다시 입력하세요");
							}
							}
							
							//비밀번호 입력
							while(true) {
							pw = Ci.r("비밀번호");
							if (pw.length() > 0) {
								break;
							} else {
								Cw.wn("다시 입력하세요");
							}
							
							}
							break;
						//14세 이상
						case "g":
							//아이디
								while(true) {
								id = Ci.r("아이디");
								if (id.length() > 0) {
									break;
								} else {
									Cw.wn("다시 입력하세요");
								}
								}
								//비밀번호 입력
								while(true) {
								pw = Ci.r("비밀번호");
								if (pw.length() > 0) {
									break;
								} else {
									Cw.wn("다시 입력하세요");
								}
								
								}
								break;
								
						//이전 메뉴
						case "x":
							return;
					}
					Db.dbExecuteUpdate("insert into s_member values('"+id+"','"+ pw+"')");
					Cw.wn("회원가입 완료");	
					Site_main.run();
					}
					
				
				}
}
