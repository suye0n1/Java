/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module Java_Mysql_board {
	requires java.sql;
}