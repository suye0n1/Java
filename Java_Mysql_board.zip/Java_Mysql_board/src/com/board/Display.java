package com.board;


public class Display {

	private static String TITLE_1 = "♥";
	private static String TITLE_2 = "FAMILY BOARD";
	
	static public void title() {
		System.out.print(TITLE_1);
		System.out.print(TITLE_2);
		System.out.println(TITLE_1);
	}
	
	static private String MAIN_MENU_BAR = "===========================================================";
	static private String MAIN_MENU	 	= "1.글 리스트 2.글 읽기 3.글 쓰기 4.글 삭제 5.글 수정 e:프로그램 종료 0.관리자";
	
	static public void MainMenu() {
		System.out.println(MAIN_MENU_BAR);
		System.out.println(MAIN_MENU);
		System.out.println(MAIN_MENU_BAR);
		
	}
}
