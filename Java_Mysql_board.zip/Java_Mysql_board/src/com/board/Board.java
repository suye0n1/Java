package com.board;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Board {
	
		Connection con = null;
		Statement st = null;
		ResultSet result = null;
		
		//throws IOException
		void run() throws IOException {
			dbInit();
			Display.title();
			Display.MainMenu();
			
//			dbExecuteQuery("select * from tottenham_squad where p_number=7");
			
			//Scanner sc=new Scanner(System.in);를 해주면 공백 인식 불가능
			//그래서 BufferedReader 함수를 사용해줘야함
			//*주의점
			//첫번째는 readLine()시 리턴값을 String으로 고정되기에 String이 아닌 다른타입으로 입력을 받을려면 형변환을 꼭 해주어야한다는 점이다. 
            //두번째는 예외처리를 꼭 해주어야한다는 점이다. readLine을 할때마다 try & catch를 활용하여 예외처리를 해주어도 되지만 대개 throws IOException을 통하여 작업한다. 
		
			//	Scanner sc=new Scanner(System.in);
			
			loop:
				while(true) {
					dbPostCount();
					System.out.println("명령을 입력하세요:");
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					switch(br.readLine()) {
					
					case "1":
						System.out.println("☆글 리스트☆");
						try {
							result = st.executeQuery("select * from board");
							while(result.next()) {
								// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
							String no = result.getString("no");
							String title = result.getString("title");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
							String id = result.getString("id");
							String dt = result.getString("dt");
							String click = result.getString("click");
							String content = result.getString("content");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
							
							System.out.println("================================================");
							System.out.println("글 번호: "+no);
							System.out.println("글제목: "+title);
							System.out.println("작성자: "+id);
							System.out.println("글내용: "+dt);
							System.out.println("글제목: "+title);
							System.out.println("작성자: "+click);
							System.out.println("글내용: "+content);
							System.out.println("================================================");
							System.out.println("");
							}
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
						break;
					
					case "2":
						System.out.println("☆글 읽기☆");
						System.out.println("읽을 글 번호를 입력하세요");
						String ReadNo = br.readLine();
						
						try {
							result = st.executeQuery("select * from board where no ="+ReadNo);
							result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
							String title = result.getString("title");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
							String content = result.getString("content");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
							String id = result.getString("id");
							
							System.out.println("글제목: "+title);
							System.out.println("작성자: "+id);
							System.out.println("글내용: "+content);
							
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
						break;
						
					case "3":
						System.out.println("☆글 쓰기☆");
						System.out.println("제목을 입력해주세요:");
						String title = br.readLine();
						System.out.println("글내용을 입력해주세요:");
						String content = br.readLine();
						System.out.println("작성자id를 입력해주세요:");
						String id = br.readLine();
						
						try {
							st.executeUpdate("insert into board (title,id,dt,content,click)"
									+" values ('"+title+"','"+id+"',now(),'"+content+"',0)");
							System.out.println("글등록 완료");
						} catch (SQLException e) {
							e.printStackTrace();
						}
						break;
						
					case "4":
						System.out.println("☆글 삭제☆");
						System.out.println("삭제할 글 번호를 입력하세요");
						String DelNo = br.readLine();
						//dbExecuteUpdate
						dbExecuteUpdate("delete from board where no="+DelNo);
						
						break;
						
					case "5":
						System.out.println("☆글 수정☆");
						System.out.println("수정할 글 번호를 입력하세요");
						String EditNo = br.readLine();
						
						System.out.println("제목 수정:");  //제목 수정
						String EditTitle = br.readLine();
						System.out.println("작성자 수정:");  //작성자 수정
						String EditId = br.readLine();
						System.out.println("내용 수정:");  //내용 수정
						String EditContent = br.readLine();
				
						dbExecuteUpdate("update board set title='"+EditTitle+"',id='"+EditId+"',content='"+EditContent+"' where no="+EditNo);
						break;
					
					case "0":
						System.out.println("☆관리자☆");
						break;
					case "6":
						System.out.println("☆프로그램이 종료되었습니다.☆");
						break loop;

				}
			
				}
			
			//오류가 없는데 sql 테이블에 데이터가 추가 안됨/Database를 되도록 1개만 만들어서 쓰기
		//	dbExecuteUpdate("insert into board(title, id, dt, click, content,b_re_count,b_re_num,b_re_text) values(\"안산 맛집 리스트\", \"soo\", now(), 3, \"퍼멘트브레드\",1,3,\"크로와상 존맛\");");
		//board 테이블 모두 삭제
	//	dbExecuteUpdate("delete from board where no =7");
			

		}
		
		private void dbInit() {
			try {
				// (1/n) 디비 접속 정보 넣어서 접속하기
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/board", "root", "root");
				// (2/n) Statement 객체 얻어오기.
				st = con.createStatement();	// Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열 수있다.
			} catch (SQLException e) {
				System.out.println("SQLException: " + e.getMessage());
				System.out.println("SQLState: " + e.getSQLState());
			}
		}
		
		private void dbExecuteQuery(String query) {
			try {
				
			result = st.executeQuery(query);
				
				while (result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					String name = result.getString("p_name");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
					System.out.println(name);
				}
			} catch (SQLException e) {
				System.out.println("SQLException: " + e.getMessage());
				System.out.println("SQLState: " + e.getSQLState());
			}
		}	
		private void dbExecuteUpdate(String query) {
			try {
				// (3/n) Statement 객체의 executeUpdate함수에 sql문 실어서 디비에서 실행되게 하기
				int resultCount = st.executeUpdate(query); // 이거 하는 순간 디비에 sql(쿼리) 날아감. (디비에 반영됨)
				System.out.println("처리된 행 수:"+resultCount);
			} catch (SQLException e) {
				System.out.println("SQLException: " + e.getMessage());
				System.out.println("SQLState: " + e.getSQLState());
			}
		}	
		
		private void dbPostCount() {	
			try {
				result = st.executeQuery("select count(*) from board");
				result.next();
				String count = result.getString("count(*)");
				System.out.println("글 개수는 "+count+"개 입니다");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

