package com.board;

import java.io.IOException;

public class Main {
	//throws IOException
	public static void main(String[] args) throws IOException {
		Board board = new Board();
		board.run();

	}
}
