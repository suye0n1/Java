package com.board;

import java.sql.SQLException;

import com.util.Ci;
import com.util.Db;

public class Read {
	public static void run() {
		
		System.out.println("☆글 읽기☆");
		String readNo =Ci.r("읽을 글 번호를 입력하세요");
		
		try {
			Db.result = Db.st.executeQuery("select * from board where no ="+readNo);
			Db.result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
			String title = Db.result.getString("title");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String content = Db.result.getString("content");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String id = Db.result.getString("id");
			
			System.out.println("===================");
			System.out.println("글제목: "+title);
			System.out.println("작성자: "+id);
			System.out.println("글내용: "+content);
			System.out.println("===================");
			
			
		
				System.out.println("댓글을 작성하려면 글 번호를 입력하세요");
				System.out.println("x:나가기");
				//b_re_count,b_ori_num,b_re_text
				String b_ori_num = Ci.rl("글 번호");
				String b_re_text = Ci.rl("댓글 내용을 입력하세요");
				
			
				try {
					String re = ("insert into board (b_ori_num,b_re_text)"
							+" values ('"+b_ori_num+"','"+b_re_text+"')");
					//로그 남기기
					System.out.println(re);
					Db.st.executeUpdate(re);
					System.out.println("댓글이 작성되었습니다.");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}

