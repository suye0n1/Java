package com.board;

import com.util.Ci;
import com.util.Db;

public class Re_Edit {
	public static void run() {
		System.out.println("☆댓글 수정☆");
		String edit_re_num = Ci.r("글 번호를 입력하세요");
		
		//댓글 내용 수정
		String edit_re_text =Ci.rl("수정할 내용");

		Db.dbExecuteUpdate("update board set b_re_text='"+edit_re_text+"' where no="+edit_re_num);
	}
}
