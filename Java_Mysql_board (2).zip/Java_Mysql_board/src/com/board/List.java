package com.board;

import java.sql.SQLException;

import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class List {
	
	public static final int PER_PAGE =3;

	static int startIndex = 0; //현재 페이지의 첫 글 인덱스 
	static int currentPage = 1; //현재 페이지
	static int totalPage = 0;
	
	public static void run() {

	if(Db.getPostCount() % PER_PAGE > 0) {
		totalPage = Db.getPostCount() / PER_PAGE + 1;
	} else {
		totalPage = Db.getPostCount() / PER_PAGE;
	}
	
//	Cw.wn("총 페이지 수:"+totalPage);
	
	String cmd;
	
	//글 리스트
	while(true) {
		cmd = Ci.r("페이지 번호를 입력하세요(x:이전 메뉴)");
		Cw.wn();
	
	if(cmd.equals("x")) {
		break;
	}
	
	currentPage = Integer.parseInt(cmd);
	
	if(currentPage > totalPage || currentPage < 1) {
		Cw.wn("페이지 범위에 맞는 값을 넣어주세요");
		continue;	//while문 다시 돌리기
	}
	
	startIndex = (currentPage - 1) * PER_PAGE; //페이지의 첫 인덱스를 계산해서 저장
//	select count(*) from board where b_ori_num is null; /댓글 제외시키기
	String sql = "select * from board where b_ori_num is null limit "+startIndex+","+PER_PAGE;
	System.out.println("☆글 리스트☆");
	Db.dbPostCount();
//	String sql = "select * from board limit "+startIndex+","+PER_PAGE;
	
	try {
		//select * from board limit 0,3; (첫페이지, 세개)

	//	Cw.wn("전송한sql문:"+sql);
		Db.result = Db.st.executeQuery(sql);

	//	result = st.executeQuery("select * from board");
		while(Db.result.next()) {
			// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
		String no = Db.result.getString("no");
		String title = Db.result.getString("title");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
		String id = Db.result.getString("id");
		String dt = Db.result.getString("dt");
		String click = Db.result.getString("click");
		String content = Db.result.getString("content");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
		
		System.out.println("================================================");
		System.out.println("글 번호: "+no);
		System.out.println("글 제목: "+title);
		System.out.println("작성자: "+id);
		System.out.println("작성 시간: "+dt);
		System.out.println("조회수: "+click);
		System.out.println("글 내용: "+content);
		System.out.println("================================================");
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}

	
}
	//검색어를 입력받으면 리스트 츨력
	public static void search() {
		String cmd;
		cmd=Ci.rl("검색어를 입력하세요(x:나가기)");
		if(cmd.equals("x")) {
			return;
		}	else {
			searchList(cmd);
		}
	}
	//리스트-검색 처리
	public static void searchList(String searchWord) {
		
		//전체 페이지 수 구하기 ?????
//		count = Db.getPostCountSearch(searchWord);
//		if(count % PER_PAGE > 0) {
//			totalPage = count / PER_PAGE + 1;
//		}	else {
//			totalPage = count / PER_PAGE;
//		}
//		Cw.wn("총 페이지 수:"+totalPage);
//		
		
		//CREATE DATABASE board  CHARACTER SET UTF8MB4;
		//
		//show databases;
		//use board;
		//
		//create table board(
		//no int primary Key auto_increment, #고유 번호
		//title char(200), #글 제목
		//id char(100), #작성자
		//dt datetime, #작성시간
		//click int, #조회수
		//content text  #글 내용
		//);
		//
		//select * from board;
		//select * from board limit 0,2;
		//select * from board limit 2,3;
		//
		//drop table board;
		//insert into board(title, id, dt, click, content) values("안산 맛집 리스트", "soo", now(), 3, "포크너"); #datetime values: now()
		//insert into board(title, id, dt, click, content) values("쩝쩝박사", "ji", now(), 10, "열라면 끓일 때 마늘, 후추 필수");
		//insert into board(title, id, dt, click, content) values("hm카페", "mi", now(), 10, "크로와상, 치아바타");
		//insert into board(title, id, dt, click, content) values("테스트", "테스트", now(), 2, "테스트");
		//insert into board(title, id, dt, click, content) values("테스트", "테스트", now(), 7, "테스트");
		//insert into board(title, id, dt, click, content) values("테스트", "테스트", now(), 4, "테스트");
		//insert into board(title, id, dt, click, content) values("테스트", "테스트", now(), 7, "테스트");
		//
		//alter table board add b_re_count int; #댓글 수 
		//alter table board add b_ori_num int; #댓글 번호
		//alter table board add b_re_text text; #댓글 내용
		//commit;
		//
		//insert into board(b_re_count,b_ori_num,b_re_text) values(3,1,"여기 존맛"); 
		//insert into board(b_re_count,b_ori_num,b_re_text) values(10,2,"도전!!!!!");
		//insert into board(b_re_count,b_ori_num,b_re_text) values(10,3,"빵 맛있어요");
		//delete from board where no=5
		
	}
}

