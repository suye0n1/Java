package com.board;

import com.util.Ci;
import com.util.Db;

public class Edit {
	
	public static void run() {
		System.out.println("☆글 수정☆");
		String EditNo = Ci.r("수정할 글 번호를 입력하세요");
		
		//제목 수정
		String EditTitle =Ci.rl("제목 수정");
		//작성자 수정
		String EditId =  Ci.rl("작성자 수정");
		//내용 수정
		String EditContent = Ci.rl("내용 수정");

		Db.dbExecuteUpdate("update board set title='"+EditTitle+"',id='"+EditId+"',content='"+EditContent+"' where no="+EditNo);
	}
}
