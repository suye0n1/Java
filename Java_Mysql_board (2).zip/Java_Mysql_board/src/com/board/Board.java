package com.board;

import java.sql.SQLException;

import com.util.Ci;
import com.util.Cw;
import com.util.Db;

public class Board {
	
		void run() {
			Db.dbInit();
			Display.title();
			Display.MainMenu();
			
			
//			dbExecuteQuery("select * from tottenham_squad where p_number=7");
			
			//Scanner sc=new Scanner(System.in);를 해주면 공백 인식 불가능
			//그래서 BufferedReader 함수를 사용 or  sc.nextLine() 사용
			//*주의점
			//첫번째는 readLine()시 리턴값을 String으로 고정되기에 String이 아닌 다른타입으로 입력을 받을려면 형변환을 꼭 해주어야한다는 점이다. 
            //두번째는 예외처리를 꼭 해주어야한다는 점이다. readLine을 할때마다 try & catch를 활용하여 예외처리를 해주어도 되지만 대개 throws IOException을 통하여 작업한다. 
		
			//	Scanner sc=new Scanner(System.in);
			
			loop:
				while(true) {
					Cw.wn();
					String cmd=Ci.r("명령을 입력하세요");
					Cw.wn("");
					switch(cmd) {
					
					case "1":
						List.run();
						break;
					
					case "2":
						Read.run(); //댓글 쓰기
						break;
						
					case "3":
						Write.run();
						break;
						
					case "4":
						Delete.run();
						break;
						
					case "5":
						Edit.run();
						break;
						
					case "6": //댓글 보기
						Db.dbReCount(); //댓글 수
						Reply.run();
						break;
						
					case "7": //댓글 수정
						Re_Edit.run();
						break;
						
					case "0":
						System.out.println("☆관리자☆");
						break;
					case "e":
						System.out.println("☆프로그램이 종료되었습니다.☆");
						break loop;
				}
			
				}
			

			

		}

	}

