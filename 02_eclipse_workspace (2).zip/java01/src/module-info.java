/**
 * 
 */
/**
 * @author GDJ 59
 *
 */
module java01 {
}