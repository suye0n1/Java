package cafe;

//컨트롤 시프트 오
import java.util.Scanner;

public class New_main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String cmd;

		loop_a: while (true) {
			System.out.print("명령을 입력해주세요:[1.1번 메뉴/2.2번 메뉴/e:종료]");
			cmd = sc.next();

//			1번 메뉴
			switch (cmd) {
			case "1":
				System.out.println("=====음료 리스트====");
				System.out.println("1번");
				loop_b: while (true) {
					System.out.println("[1.흑임자라떼/2.말차프라푸치노/3.자몽에이드/x:이전 메뉴]");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						System.out.println("흑임자라떼");
//					switch에 대한 break
						break;

					case "2":
						System.out.println("말차프라푸치노");
						break;

					case "3":
						System.out.println("자몽에이드");
						break;

					case "x":
						break loop_b;
					}
				}
				break;

			case "2":
				System.out.println("====디저트 리스트====");
				System.out.println("2번");

//				2번 메뉴
				loop_c: while (true) {
					System.out.println("[1.소금마카롱/2.브라우니마카롱/3.인절미마카롱/y:이전 메뉴]");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						System.out.println("소금마카롱");

						break;

					case "2":
						System.out.println("브라우니마카롱");
						break;

					case "3":
						System.out.println("인절미마카롱");
						break;

					case "y":
						break loop_c;
					}
				}
				break;

			case "e":
				break loop_a;

			}
		}
		System.out.println("프로그램 종료");
	}
}
