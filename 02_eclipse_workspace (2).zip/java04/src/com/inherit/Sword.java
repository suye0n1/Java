package com.inherit;

//부모 클래스 Item
public class Sword extends Item {
	int attack;
	
}
