package com.inherit;

public class Item extends GameObj {
	int weight;
	int duration;
	

}
