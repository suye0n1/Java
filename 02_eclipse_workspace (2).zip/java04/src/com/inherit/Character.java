package com.inherit;

//클래스를 상속할 때 extends 키워드 사용 GameObj가 부모 클래스 Character이 자식 클래스
public class Character extends GameObj {
	//String name;을 주지 않아도 사용 가능/부모 클래스에 있기 때문에
	int hp;
	int attack;
	
}
