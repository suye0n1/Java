package com.inherit;

//부모 클래스
//다중 상속 불가능 즉, 부모 클래스 2개 이상 안됨
public class GameObj {
	String name;
	
	//함수 선언도 가능
	void info() {
		System.out.println("이름:"+name);
	}
}
