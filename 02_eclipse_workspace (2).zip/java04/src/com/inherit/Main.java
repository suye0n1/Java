package com.inherit;

public class Main {
	public static void main(String[] args) {
		Character elf = new Character();
		elf.name = "1";
		elf.hp = 100;
		elf.info();
		
		Item book = new Item();
		book.weight = 200;
		book.name = "돌돌이";
		book.duration = 120;
		book.info();
		
		//Sword의 부모 클래스는 Item/GameObj에 있는 것도 사용 가능
		Sword shortSword = new Sword();
		shortSword.name = "단검";
		shortSword.attack = 150;
		shortSword.weight = 5;
		
	}
}
