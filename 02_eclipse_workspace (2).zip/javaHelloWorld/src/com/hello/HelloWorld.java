package com.hello;

import java.util.Scanner;

public class HelloWorld {
	public static void main(String[] args) {

		System.out.println("헬로월드");
		System.out.println("강아지");
		System.out.println(1 + 1);
		Scanner sc = new Scanner(System.in);
		String cmd = sc.next();
		System.out.println(cmd);
	}
}

//		float f1 = 1.0000001f;
//		System.out.println(f1);
//		
//		float f2 = 1.00000001f;
//		System.out.println(f2);
//		
//		double d1 = 1.000000000000001;
//		System.out.println(d1);
//		
//		double d2 = 1.0000000000000001;
//		System.out.println(d2);
//		
//		double d3 = 1.15;
//		System.out.println(d3);
//		
//		int v1 = (int)5.3;
//		System.out.println(v1);
//		
//		long v2 = (long)10;
//		System.out.println(v2);
//		
//		float v3 = (float)5.8;
//		System.out.println(v3);
//		
//		double v4 = (double)16;
//		System.out.println(v4);
//		
//		long v5 = 10L;
//		System.out.println(v5);
//		
//		long v6 = 10l;
//		System.out.println(v6);
//		
//		
//		float v7 = 5.8F;
//		System.out.println(v7);
//		
//		float v8 = 5.8f;
//		System.out.println(v8);
//		

//		
//		int r = (int)(Math.random() * 6 + 1);
//		System.out.println(r);

//		byte data1 = 3;
//		byte data2 = 5;
//		int x = data1 + data2;
//		System.out.println(x);
//		
//		int value7 = 5 + (int)3.5;
//		System.out.println(value7);
//
//		byte data3 = 3;
//		short data4 = 5;
//		double value9 = data3 + data4;
//		System.out.println(value9);

//		for(int i=1; i<=10; i++) {
//			for(int j=1; j<=10; j++) {
//				System.out.print("*");
//			}System.out.println();
//		}

//		for(int i=1; i<=10; i++) {
//			for(int j=1; j<=i; j++) {
//				System.out.print("*");
//			}System.out.println();
//		}

//		for(int i=1; i<=10; i++) {
//			for(int j=10; j>=i; j--) {
//				System.out.print("*");
//			}System.out.println();
//		}

//		for(int i=1; i<=10; i++) {
//			for(int k=1; k<=i-1; k++) {
//				System.out.print(" ");
//			}
//			for(int j=10; j>=i; j--) {
//				System.out.print("*");
//			}System.out.println("");
//		}

//		for(int i=1; i<=10; i++) {
//		for(int k=9; k>=i; k--) {
//			System.out.print(" ");
//		}
//		for(int j=10; j>=i; j--) {
//			System.out.print("*");
//		}System.out.println("");
//	}
