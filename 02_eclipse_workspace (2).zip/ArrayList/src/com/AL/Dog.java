package com.AL;

public class Dog {
	String name;
	int age;
	//생성자 함수 자동으로 생성하는 법
	//1.마우스 우클릭
	//2.팝업 메뉴에서-source-generate constructor using fields
	//3.매개변수로 받을 멤버 변수 체크 후 generate 버튼 클릭
	public Dog(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
}
