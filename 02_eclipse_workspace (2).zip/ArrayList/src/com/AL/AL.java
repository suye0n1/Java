package com.AL;

import java.util.ArrayList;
import java.util.Arrays;

public class AL {
	public static void main(String[] args) {
		
		//배열리스트
		//String(객체)이 아닌 다른 객체를 써주면 오류
 		ArrayList<String> animals = new ArrayList<>();
		animals.add("강아지");
		animals.add("토끼");
		animals.add("다람쥐");
		
		//for문 사용
		for(int i=0; i<animals.size(); i++) {
			System.out.println(animals.get(i));
		}
		
		//향상된 for문
		for(String x: animals) {
			System.out.println(x);
		}
		
		//배열리스트뿐만 아니라 다른 것들도 가능
		int []a = {1,2,3};
		for(int y: a) {
			System.out.println(y);
		}
		
		Dog dog1 = new Dog("또리", 3);
		Dog dog2 = new Dog("다오", 2);
		ArrayList<Dog> dogs = new ArrayList<>();
		dogs.add(dog1);
		dogs.add(dog2);
		
		for(Dog s: dogs) {
			System.out.println("강아지 이름: "+s.name);
			System.out.println("강아지 나이: "+s.age);
		}
		
		int[] array = new int[] {1,2,3,4,5,6};
		System.out.println(Arrays.toString(array));
		
		
	}
}
