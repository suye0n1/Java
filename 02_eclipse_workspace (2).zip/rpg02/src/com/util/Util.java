package com.util;

public class Util {
	
//	void는 return값이 없으므로 불가능 int로 선언
//	자주 쓰이는 함수는 public static함수를 선언해주면 됨 그러면 객체 생성 필요x
//	(1)
	public static int dice() {
		int r = (int)(Math.random()*6+1);
		return r;
}
//	(2)
	public static int dice(int n) {
		int r = (int)(Math.random()*n+1);
		return r;
}
}
