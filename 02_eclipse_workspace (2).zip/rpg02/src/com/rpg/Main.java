package com.rpg;

import com.util.Util;

public class Main {
	
	public static void main(String[] args) {
//		(1)
//		Util u = new Util;  객체 생성한 상태
//		int random = u.dice();
//		System.out.println(r);
		
//		객체 생성 필요없고 함수를 적어주면 됨
//		int random = Util.dice();
//		Util.dice()라는 함수는 Main.java에서 객체 생성 하지 않고 바로 사용 가능
//		System.out.println("주사위:"+random);
		
//		(2)
		int random = Util.dice(6);
		System.out.println(random);
//		숫자6까지 나옴
		
		
		
//		캐릭터를 담은 박스 선언
		Character elf = new Character(); 
		elf.name = "캐릭터";
		elf.hp = 100;
		elf.attack = 50;
		
		Monster orc = new Monster();
		orc.name = "고양이";
		orc.hp = 70;
		orc.attack = 30;
		
		Dog a = new Dog();
		a.name = "강아지";
		a.hp = 100;
		a.attack = 20;
		
		
		elf.info();
		orc.info();
		a.info();
		
		
	}

}
